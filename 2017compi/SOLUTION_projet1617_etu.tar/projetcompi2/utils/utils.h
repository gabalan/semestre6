#ifndef UTILS_H
#define UTILS_H

void error(char * message);

#endif
