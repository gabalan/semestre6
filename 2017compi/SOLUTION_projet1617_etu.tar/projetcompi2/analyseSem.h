
void exSem(argType *glob,symbolTag* table,nodeType* C);

