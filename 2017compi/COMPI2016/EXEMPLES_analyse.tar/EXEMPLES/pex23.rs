Les variables globales:
------------------------:
variable X1 DIM:0,TAILLE:0,TYPEF:313valeur 0 
variable X2 DIM:0,TAILLE:0,TYPEF:313valeur 0 
variable X3 DIM:0,TAILLE:0,TYPEF:314valeur 0 
variable X4 DIM:2,TAILLE:0,TYPEF:313valeur 0 
fin d'environnement 

Les fonctions:
------------------------:
fin de liste de fonctions 

Le programme principal:
------------------------:
Se Se Se Se Se Af X1 X1 Af X2 + + X2 X3 X1 Af X1 Ind X4 X1 Af X2 + Ind X4 X4 X3 Af X1 Ind Ind X4 + X1 1 X2 Af X2 + X2 true 
erreur de typage

TYPERROR: op entier sur args non-entiers: ligne 9 
TYPERROR: affectation de types incoherents : ligne 11 
TYPERROR: index non entier dans un tableau: ligne 12 
TYPERROR: op entier sur args non-entiers: ligne 15 
