trouve X en position 0x25af8b0 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :0 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :1 
trouve foo en position 0x25b7c80 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :0 
trouve X en position 0x25b7dc0 
trouve X en position 0x25b8090 
trouve X en position 0x25b8220 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :1 
trouve foo en position 0x25af520 
trouve foo en position 0x25b8820 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :0 
trouve foo en position 0x25b8a50 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :5 
trouve X1 en position 0x25af1e0 
trouve X1 en position 0x25af1e0 
trouve foo en position 0x25af520 
trouve X2 en position 0x25af230 
Les variables globales:
------------------------:
variable X1 DIM:0,TAILLE:0,TYPEF:313valeur 0 
variable X2 DIM:0,TAILLE:0,TYPEF:313valeur 0 
fin d'environnement 

Les fonctions:
------------------------:
nfon:foo
 parametres:
variable X DIM:0,TAILLE:0,TYPEF:313valeur 0 
fin d'environnement 
var locales:
variable foo DIM:0,TAILLE:0,TYPEF:313valeur 0 
variable n DIM:0,TAILLE:0,TYPEF:313valeur 0 
fin d'environnement 
corps (notation prefixe) :
IfThEl Eq X 0  Af foo 1 IfThEl Lt 0 X  Af foo * X Ap foo ArgAp - X 1 Af foo 0 
 type resultat:
DIM:0,TAILLE:0,TYPEF:313

fin de liste de fonctions 

Le programme principal:
------------------------:
Se Af X1 5 Af X2 Ap foo ArgAp X1 
programme bien type