Les variables globales:
------------------------:
variable X1 DIM:0,TAILLE:0,TYPEF:313valeur 0 
variable X2 DIM:0,TAILLE:0,TYPEF:313valeur 0 
variable Y DIM:0,TAILLE:0,TYPEF:314valeur 0 
fin d'environnement 

Les fonctions:
------------------------:
fin de liste de fonctions 

Le programme principal:
------------------------:
Se Af Y false IfThEl Y  Af X2 X1 Af X2 + X1 1 
programme bien type