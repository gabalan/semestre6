Les variables globales:
------------------------:
variable X1 DIM:0,TAILLE:0,TYPEF:313valeur 0 
variable X2 DIM:0,TAILLE:0,TYPEF:313valeur 0 
variable X3 DIM:1,TAILLE:0,TYPEF:313valeur 0 
variable X4 DIM:2,TAILLE:0,TYPEF:313valeur 0 
fin d'environnement 

Les fonctions:
------------------------:
fin de liste de fonctions 

Le programme principal:
------------------------:
IfThEl Lt X1 X2  Af X1 Ind X3 * + X1 X2 10 Af X1 Ind X3 1 
programme bien type