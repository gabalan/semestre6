trouve X1 en position 0x746820 
trouve X2 en position 0x74ea10 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :10 
trouve X3 en position 0x74ef40 
trouve X1 en position 0x74f030 
Les variables globales:
------------------------:
variable X1 DIM:0,TAILLE:0,TYPEF:313valeur 0 
variable X2 DIM:0,TAILLE:0,TYPEF:313valeur 0 
variable X3 DIM:1,TAILLE:0,TYPEF:314valeur 0 
variable X4 DIM:2,TAILLE:0,TYPEF:314valeur 0 
fin d'environnement 

Les fonctions:
------------------------:
fin de liste de fonctions 

Le programme principal:
------------------------:
Af X1 Ind X3 * + X1 X2 10 
erreur de typage