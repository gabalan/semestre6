/* codey86.h */
#ifndef CODEY86_H
#define CODEY86_H 
/* ----------------------------types-------------------------------------------- */
/* table de symboles:= liste de triples (identificateur, valeur, numero) */
typedef struct celltab{
  char *ID;
  int  VAL;
  int  NUM;
  struct celltab *SUIV;} *TAB;
/*---------------------allocation memoire----------------------------------------*/
extern TAB Taballoc(); /* alloue l' espace memoire d'un celltab                  */
/*alloue l' espace memoire aux ingrediets d'un quadruplet                        */
extern void Quadalloc(char **petiq,char **parg1,char **parg2,char **pres);
/*---------------------de-C3A-vers-Y86-------------------------------------------*/
/*   table des symboles                                                          */
extern int ecrire_tab(TAB rho);/* affiche la table                               */
extern TAB recht(char *chaine, TAB listident);/* retourne la position de chaine  */
extern TAB env_to_tab(ENV rho); /* calcule les num et renvoie la table           */
/*   traduction                                                                  */
extern BILQUAD quad2y86(BILQUAD c3a); /* traduit C3A vers Y86                    */
extern void ecrire_y86(BILQUAD y86);  /* ecrit le programme Y86                  */
/* test                                                                          */
extern void test_trady86(int n, NOE c);/* teste la traduction c3a --> y86        */
/*-------------------VARIABLES globales -----------------------------------------*/
extern TAB tabsym;           /* table des symboles             */
#endif
