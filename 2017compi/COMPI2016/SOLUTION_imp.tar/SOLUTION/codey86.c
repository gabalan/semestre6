/* codey86.c */
#include <assert.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arbre.h"
#include "codec3a.h"
#include "codey86.h"
#include "iimp.tab.h"
/* iimp.tab.h APRES arbre,h, sinon le type NOE est inconnu de gcc    */
/*-------------------------------------------------------------------*/
/* ----------------------------types---------------------------------*/
/*  NOE,PILCOM,ENV : definis dans arbre.h                            */
/*-------------------------------------------------------------------*/
/*---------------------allocation memoire----------------------------*/
TAB Taballoc()
{
  return((TAB)malloc(sizeof(struct celltab)));
} 
/*alloue l' espace memoire aux ingredients d'un quadruplet                        */
extern void Quadalloc(char **petiq,char **parg1,char **parg2,char **pres)
{*petiq=Idalloc();*parg1=Idalloc();*parg2=Idalloc();*pres=Idalloc();
}
/*-------------------------------------------------------------------------------*/ 
/*------------------------C3A-vers-Y86-------------------------------------------*/
/*   table des symboles                                                          */

/* affiche la table */  
int ecrire_tab(TAB rho)
{ if (rho==NULL)
    {printf("fin de table \n");
      return(EXIT_SUCCESS);}
  else
    {printf("variable: %6s valeur: %6d numero: %6d\n",rho->ID,rho->VAL,rho->NUM);
      ecrire_tab(rho->SUIV); 
      return(EXIT_SUCCESS);
    };
}

/* retourne la position de chaine, NULL si la chaine est absente   */
TAB recht(char *chaine, TAB listident)
{if (listident!=NULL)
    {if (strcmp(listident->ID,chaine)==0)
        {return listident;}
      else
	return recht(chaine,listident->SUIV);
    }
  else
    return NULL;
}

/* calcule les num a partir de n et renvoie la table */
TAB env_to_tab_aux(ENV rho, int n)
{TAB res;
  if (rho==NULL)
    res=NULL;
  else
    {res=Taballoc();
     res->ID= rho->ID;
     res->VAL= rho->VAL;
     res->NUM= n;
     res->SUIV=env_to_tab_aux(rho->SUIV,n+1);
    }
  return(res);
}
  
/* calcule les num et renvoie la table */
/* numeros >=1, on reserve 0 pour le res du ssprog  MUL */ 
TAB env_to_tab(ENV rho)
{
  return(env_to_tab_aux(rho,1));}

/* LA table des symboles */
TAB tabsym;

/* traduit C3A vers Y86 
   argument: un programme C3A sous forme de biliste de quadruplets; non-modifie  
   resultat: un programme y86 sous forme de biliste de quadruplets; 
   resultat ne partage rien avec l'argument  */
BILQUAD quad2y86(BILQUAD c3a)
{extern TAB tabsym;                            /* var globale: table des symboles */
  tabsym=env_to_tab(envrnt);
    BILQUAD bilres;                              /* resultat               */
  BILQUAD init1, main2, mul3, data4;           /* decompose en 4 parties */
  bilres=bilquad_vide();
  init1=bilquad_vide();
  main2=bilquad_vide();
  mul3=bilquad_vide();
  data4=bilquad_vide();
  QUAD nquad;                                   /* nouveau quadruplet                */
  /*------------------------------------init1--------------------------------------*/
  /* .pos 0 #debut zone code */                                 
  nquad=creer_quad("",0,".pos","0","#debut zone code ");
  init1=concatq(init1,creer_bilquad(nquad));
  /* INIT:irmovl Data,%edx #adresse de la zone de donnees */
  nquad=creer_quad("INIT",irmovl,"Data,","%edx","#adresse de la zone de donnees");
  init1=concatq(init1,creer_bilquad(nquad));
  /*  irmovl 256,%eax			#espace pile*/
  nquad=creer_quad("",irmovl,"256,","%eax","#espace pile");
  init1=concatq(init1,creer_bilquad(nquad));
  /*  addl   %edx,%eax                              */
  nquad=creer_quad("",addl,"%edx,","%eax","");
  init1=concatq(init1,creer_bilquad(nquad));
  /*   rrmovl %eax,%esp			#init pile  */
  nquad=creer_quad("",rrmovl,"%eax,","%esp","#init pile ");
  init1=concatq(init1,creer_bilquad(nquad));
  /*   rrmovl %eax,%ebp                             */
  nquad=creer_quad("",rrmovl,"%eax,","%ebp","");
  init1=concatq(init1,creer_bilquad(nquad));
  /*------------------------------------main2--------------------------------------*/ 
  /* main2: MAIN */
  QUAD cquad;                                   /* quadruplet  c3a  courant          */
  char *tquad;                                  /* chaine=quadruplet  c3a            */
  int op;                                       /* operateur c3a courant             */
  int newop;                                    /* operateur y86     courant         */
  char *arg1,*arg2,*res;                        /* champs du quadruplet c3a courant  */
  char *netiq,*narg1,*narg2,*nres;              /* champs du quadruplet y86 cree     */
  int num;                                      /* numero de variable                */
  TAB advar;                                    /* adresse dans la table des symboles*/
  cquad=c3a.debut;
  while (cquad != NULL)
    {       op=cquad->OP;arg1=cquad->ARG1;arg2=cquad->ARG2;res=cquad->RES;
      switch(op)
	{case Pl:/* plus  X Y Z                                                       */
	    /*                                 Q1 mrmovl x(%edx),%eax  #quadsource    */
	    Quadalloc(&netiq,&narg1,&narg2,&nres);/* allouer memoire aux ingredients  */
	    netiq=cquad->ETIQ;
	    newop=mrmovl;
	    advar=recht(arg1,tabsym);          /* adresse de X=arg1 dans la TS        */
	    num=advar->NUM;                    /* numero  de arg1                     */
	    num=4*num;                         /* placement de X    dans la memoire   */
	    sprintf(narg1,"%d",num);           /* narg1 :=chaine(num)+ "(%edx),"      */
      	    strcat(narg1,"(%edx),");
      	    narg2="%eax";
	    tquad=(char *)malloc((MAXQUAD)*sizeof(char));  /* chaine =  quad courant  */
	    free(nres);                                    /* chaine =#c3a+quadcourant*/
	    nres=(char *)malloc((MAXQUAD+5)*sizeof(char)); 
	    secrire_quad(tquad,cquad);          /* string := quadruplet source        */
	    	    strcpy(nres,"#trad ");
	    	    nres=strcat(nres,tquad);
	    	    nquad=creer_quad(netiq,newop,narg1,narg2,nres);/* quadruplet objet (y86)  */
	    	    main2=concatq(main2,creer_bilquad(nquad));
	    	    /*                                 Q2 mrmovl y(%edx),%ebx                 */
	    Quadalloc(&netiq,&narg1,&narg2,&nres);/* allouer memoire aux ingredients  */
	    netiq="";
	    newop=mrmovl;
	    advar=recht(arg2,tabsym);          /* adresse de Y=arg2 dans la TS        */
	    num=advar->NUM;                    /* numero  de arg2                     */
	    num=4*num;                         /* placement de Y    dans la memoire   */
	    sprintf(narg1,"%d",num);           /* narg1 :=chaine(num)+ "(%edx),"      */
      	    strcat(narg1,"(%edx),");
      	    narg2="%ebx";
	    nres="";
	    nquad=creer_quad(netiq,newop,narg1,narg2,nres);
	    main2=concatq(main2,creer_bilquad(nquad));
	    	    /*                                  Q3 addl %eax,%ebx                     */
	    nquad=creer_quad("",addl,"%eax,","%ebx","");
  	    main2=concatq(main2,creer_bilquad(nquad));
	    	    /*                                   Q4 rmmovl %ebx,z(%edx)               */
	    Quadalloc(&netiq,&narg1,&narg2,&nres);/* allouer memoire aux ingredients  */
	    netiq="";
	    	    newop=rmmovl;
	    narg1="%ebx,";
	    	    advar=recht(res,tabsym);           /* adresse de Z=res  dans la TS */
	    num=advar->NUM;                    /* numero  de res               */
	    	    num=4*num;                         /* placement de Z dans la memoire   */
	    sprintf(narg2,"%d",num);           /* narg1 :=chaine(num)+ "(%edx),"   */
	          	    strcat(narg2,"(%edx)");
     	    nres="";
	    	    nquad=creer_quad(netiq,newop,narg1,narg2,nres);
	      	    main2=concatq(main2,creer_bilquad(nquad));
	    	    break;
	case Mo:/* moins  X Y Z                                                      */
	  /*                                 Q1   mrmovl x(%edx),%ebx  #quadsource   */
	  Quadalloc(&netiq,&narg1,&narg2,&nres);/* allouer memoire aux ingredients   */
	  netiq=cquad->ETIQ;
	  newop=mrmovl;
	  advar=recht(arg1,tabsym);          /* adresse de X=arg1 dans la TS         */
	  num=advar->NUM;                    /* numero  de arg1                      */
	  num=4*num;                         /* placement de X    dans la memoire    */
	  sprintf(narg1,"%d",num);           /* narg1 :=chaine(num)+ "(%edx),"       */
	  strcat(narg1,"(%edx),");
	  narg2="%ebx";
	  tquad=(char *)malloc((MAXQUAD)*sizeof(char));  /* chaine =  quad courant   */
	  free(nres);                                    /* chaine =#c3a +quad courant*/
	  nres=(char *)malloc((MAXQUAD+5)*sizeof(char)); 
	  secrire_quad(tquad,cquad);          /* string := quadruplet source         */
	  strcpy(nres,"#trad ");
	  nres=strcat(nres,tquad);
	  nquad=creer_quad(netiq,newop,narg1,narg2,nres);/* quadruplet objet (y86)   */
	  main2=concatq(main2,creer_bilquad(nquad));
	  /*                                 Q2 mrmovl y(%edx),%eax                  */
	  Quadalloc(&netiq,&narg1,&narg2,&nres);/* allouer memoire aux ingredients   */
	  netiq="";
	  newop=mrmovl;
	  advar=recht(arg2,tabsym);          /* adresse de Y=arg2 dans la TS         */
	  num=advar->NUM;                    /* numero  de arg2                      */
	  num=4*num;                         /* placement de Y    dans la memoire    */
	  sprintf(narg1,"%d",num);           /* narg1 :=chaine(num)+ "(%edx),"       */
	  strcat(narg1,"(%edx),");
	  narg2="%eax";
	  nres="";
	  nquad=creer_quad(netiq,newop,narg1,narg2,nres);
	  main2=concatq(main2,creer_bilquad(nquad));
	  /*                                  Q3 subl %eax,%ebx                      */
	  nquad=creer_quad("",subl,"%eax,","%ebx","");
	  main2=concatq(main2,creer_bilquad(nquad));
	  /*                                   Q4 rmmovl %ebx,z(%edx)                */
	  Quadalloc(&netiq,&narg1,&narg2,&nres);/* allouer memoire aux ingredients   */
	  netiq="";
	  newop=rmmovl;
	  narg1="%ebx,";
	  advar=recht(res,tabsym);           /* adresse de Z=res  dans la TS */
	  num=advar->NUM;                    /* numero  de res               */
	  num=4*num;                         /* placement de Z dans la memoire   */
	  sprintf(narg2,"%d",num);           /* narg1 :=chaine(num)+ "(%edx),"   */
	  strcat(narg2,"(%edx)");
	  nres="";
	  nquad=creer_quad(netiq,newop,narg1,narg2,nres);
	  main2=concatq(main2,creer_bilquad(nquad));
	  break;
	case Mu:/* mul  X Y Z                                                         */
	  /*                                 Q1 mrmovl x(%edx),%eax  #quadsource      */
	  Quadalloc(&netiq,&narg1,&narg2,&nres);/* allouer memoire aux ingredients    */
	  netiq=cquad->ETIQ;
	  newop=mrmovl;
	  advar=recht(arg1,tabsym);          /* adresse de X=arg1 dans la TS          */
	  num=advar->NUM;                    /* numero  de arg1                       */
	  num=4*num;                         /* placement de X    dans la memoire     */
	  sprintf(narg1,"%d",num);           /* narg1 :=chaine(num)+ "(%edx),"        */
	  strcat(narg1,"(%edx),");
	  narg2="%eax";
	  tquad=(char *)malloc((MAXQUAD)*sizeof(char));  /* chaine =  quad courant    */
	  free(nres);                                    /* chaine =#c3a +quad courant*/
	  nres=(char *)malloc((MAXQUAD+5)*sizeof(char)); 
	  secrire_quad(tquad,cquad);          /* string := quadruplet source          */
	  strcpy(nres,"#trad ");
	  nres=strcat(nres,tquad);
	  nquad=creer_quad(netiq,newop,narg1,narg2,nres);/* quadruplet objet (y86)    */
	  main2=concatq(main2,creer_bilquad(nquad));
	  /*                                 Q2 mrmovl y(%edx),%ebx                   */
	  Quadalloc(&netiq,&narg1,&narg2,&nres);/* allouer memoire aux ingredients    */
	  netiq="";
	  newop=mrmovl;
	  advar=recht(arg2,tabsym);          /* adresse de Y=arg2 dans la TS          */
	  num=advar->NUM;                    /* numero  de arg2                       */
	  num=4*num;                         /* placement de Y    dans la memoire     */
	  sprintf(narg1,"%d",num);           /* narg1 :=chaine(num)+ "(%edx),"        */
	  strcat(narg1,"(%edx),");
	  narg2="%ebx";
	  nres="";
	  nquad=creer_quad(netiq,newop,narg1,narg2,nres);
	  main2=concatq(main2,creer_bilquad(nquad));
	  /*                                 Q3 pushl %ebx                            */
	  nquad=creer_quad("",pushl,"%ebx","","");
	  main2=concatq(main2,creer_bilquad(nquad));
	  /*                                 Q4 pushl %eax                            */
	  nquad=creer_quad("",pushl,"%eax","","");
	  main2=concatq(main2,creer_bilquad(nquad));
	  /*                                 Q5 call MUL                              */
	  nquad=creer_quad("",call,"MUL","","");
	  main2=concatq(main2,creer_bilquad(nquad));
	  /*                                 Q6 popl %eax                             */
	  nquad=creer_quad("",popl,"%eax","","");
	  main2=concatq(main2,creer_bilquad(nquad));
	  /*                                 Q7 popl %ebx                             */
	  nquad=creer_quad("",popl,"%ebx","","");
	  main2=concatq(main2,creer_bilquad(nquad));

	  /*                                 Q8 mrmovl 0(%edx),%eax                   */
	  nquad=creer_quad("",mrmovl,"0(%edx),","%eax","");
	  main2=concatq(main2,creer_bilquad(nquad));
	  /*                                 Q9 rmmovl %eax,z(%edx)                   */
	  Quadalloc(&netiq,&narg1,&narg2,&nres);/* allouer memoire aux ingredients    */
	  netiq="";
	  newop=rmmovl;
	  narg1="%eax,";
	  advar=recht(res,tabsym);           /* adresse de Z=res  dans la TS */
	  num=advar->NUM;                    /* numero  de res               */
	  num=4*num;                         /* placement de Z dans la memoire   */
	  sprintf(narg2,"%d",num);           /* narg2 :=chaine(num)+ "(%edx),"   */
	  strcat(narg2,"(%edx)");
	  nres="";
	  nquad=creer_quad(netiq,newop,narg1,narg2,nres);
	  main2=concatq(main2,creer_bilquad(nquad));
	  break;	    
	case Af:/* affectation var->var :   Af X Y                                    */
	  /*                                 Q1 mrmovl y(%edx),%eax   #quadsource     */  
	  Quadalloc(&netiq,&narg1,&narg2,&nres);/* allouer memoire aux ingredients    */
	  netiq=cquad->ETIQ;                  
	  newop=mrmovl;
	  advar=recht(arg2,tabsym);          /* adresse de Y=arg2 dans la TS          */
	  num=advar->NUM;                    /* numero  de arg2                       */
	  num=4*num;                         /* placement de Y    dans la memoire     */
	  sprintf(narg1,"%d",num);           /* narg1 :=chaine(num)+ "(%edx),"        */
	  strcat(narg1,"(%edx),");
	  narg2="%eax";
	  tquad=(char *)malloc((MAXQUAD)*sizeof(char));  /* chaine =  quad courant    */
	  free(nres);                                    /* chaine =#c3a +quad courant*/
	  nres=(char *)malloc((MAXQUAD+5)*sizeof(char)); 
	  secrire_quad(tquad,cquad);          /* string := quadruplet source          */
	  strcpy(nres,"#trad ");
	  nres=strcat(nres,tquad);
	  nquad=creer_quad(netiq,newop,narg1,narg2,nres);
	  main2=concatq(main2,creer_bilquad(nquad));
	  /*                                   Q2 rmmovl %eax,x(%edx)                 */
	  Quadalloc(&netiq,&narg1,&narg2,&nres);/* allouer memoire aux ingredients    */
	  netiq="";
	  newop=rmmovl;
	  narg1="%eax,";
	  advar=recht(arg1,tabsym);          /* adresse de X=arg1  dans la TS         */
	  num=advar->NUM;                    /* numero  de arg1                       */
	  num=4*num;                         /* placement de X dans la memoire        */
	  sprintf(narg2,"%d",num);           /* narg2 :=chaine(num)+ "(%edx),"        */
	  strcat(narg2,"(%edx)");
	  nres="";
	  nquad=creer_quad(netiq,newop,narg1,narg2,nres);
	  main2=concatq(main2,creer_bilquad(nquad));
	  break;
	case Afc:/* affectation const->var  :Afc C - Z                                */
	  /*                                 Q1 irmovl C,%eax  #quadsource            */
	  Quadalloc(&netiq,&narg1,&narg2,&nres);/* allouer memoire aux ingredients    */
	  netiq=cquad->ETIQ;
	  newop=irmovl;
	  sprintf(narg1,"%s,",arg1);          /* narg1 :=arg1 + ","                   */
	  narg2="%eax";
	  tquad=(char *)malloc((MAXQUAD)*sizeof(char));  /* chaine =  quad courant    */
	  free(nres);                                    /* chaine =#c3a +quad courant*/
	  nres=(char *)malloc((MAXQUAD+5)*sizeof(char)); 
	  secrire_quad(tquad,cquad);          /* string := quadruplet source          */
	  strcpy(nres,"#trad ");
	  nres=strcat(nres,tquad);
	  nquad=creer_quad(netiq,newop,narg1,narg2,nres);/* quadruplet objet (y86)    */
	  main2=concatq(main2,creer_bilquad(nquad));
	  /*                                 Q2 rmmovl %eax,z(%edx)                   */
	  Quadalloc(&netiq,&narg1,&narg2,&nres);/* allouer memoire aux ingredients    */
	  netiq="";
	  newop=rmmovl;
	  narg1="%eax,";
	  advar=recht(res,tabsym);           /* adresse de Z=res  dans la TS */
	  num=advar->NUM;                    /* numero  de res               */
	  num=4*num;                         /* placement de Z dans la memoire   */
	  sprintf(narg2,"%d",num);           /* narg2 :=chaine(num)+ "(%edx),"   */
	  strcat(narg2,"(%edx)");
	  nres="";
	  nquad=creer_quad(netiq,newop,narg1,narg2,nres);
	  main2=concatq(main2,creer_bilquad(nquad));
	  break;
	case Sk:/* skip                  */
	  /*                                 Q1 Sk #quadsource                         */
	  Quadalloc(&netiq,&narg1,&narg2,&nres);/* allouer memoire aux ingredients     */
	  netiq=cquad->ETIQ;
	  newop=nop;
	  narg1="";narg2="";
	  tquad=(char *)malloc((MAXQUAD)*sizeof(char));  /* chaine =  quad courant     */
	  free(nres);                                    /* chaine = #c3a +quad courant*/
	  nres=(char *)malloc((MAXQUAD+5)*sizeof(char));
	  secrire_quad(tquad,cquad);          /* string := quadruplet source          */
	  strcpy(nres,"#trad ");
	  nres=strcat(nres,tquad);
	  nquad=creer_quad(netiq,newop,narg1,narg2,nres);/* quadruplet objet (y86)    */
	  main2=concatq(main2,creer_bilquad(nquad));
	  break;
	case Jp:/* saut inconditionnel   */
	  /*                                 Q1   jmp res             #quadsource     */
	  Quadalloc(&netiq,&narg1,&narg2,&nres);/* allouer memoire aux ingredients    */
	  netiq=cquad->ETIQ;
	  newop=jmp;
	  narg1=cquad->RES;
	  narg2="";
	  tquad=(char *)malloc((MAXQUAD)*sizeof(char));  /* chaine =  quad courant    */
	  free(nres);                                    /* chaine =#c3a +quad courant*/
	  nres=(char *)malloc((MAXQUAD+5)*sizeof(char));
	  secrire_quad(tquad,cquad);          /* string := quadruplet source         */
	  strcpy(nres,"#trad ");
	  nres=strcat(nres,tquad);
	  nquad=creer_quad(netiq,newop,narg1,narg2,nres);/* quadruplet objet (y86)   */
	  main2=concatq(main2,creer_bilquad(nquad));
	  break;
	case Jz:/* saut si arg1 == 0     */
	  /*                                 Q1   mrmovl x(%edx),%eax #quadsource    */
	  Quadalloc(&netiq,&narg1,&narg2,&nres);/* allouer memoire aux ingredients   */
	  netiq=cquad->ETIQ;
	  newop=mrmovl;
	  advar=recht(arg1,tabsym);          /* adresse de X=arg1 dans la TS         */
	  num=advar->NUM;                    /* numero  de arg1                      */
	  num=4*num;                         /* placement de X    dans la memoire    */
	  sprintf(narg1,"%d",num);           /* narg1 :=chaine(num)+ "(%edx),"       */
	  strcat(narg1,"(%edx),");
	  narg2="%eax";
	  tquad=(char *)malloc((MAXQUAD)*sizeof(char));  /* chaine =  quad courant   */
	  free(nres);                                    /* chaine =#c3a+quad courant*/
	  nres=(char *)malloc((MAXQUAD+5)*sizeof(char)); 
	  secrire_quad(tquad,cquad);          /* string := quadruplet source         */
	  strcpy(nres,"#trad ");
	  nres=strcat(nres,tquad);
	  nquad=creer_quad(netiq,newop,narg1,narg2,nres);/* quadruplet objet (y86)   */
	  main2=concatq(main2,creer_bilquad(nquad));
	  /*                                  Q2 andl %eax,%eax                      */
	  nquad=creer_quad("",andl,"%eax,","%eax","");
	  main2=concatq(main2,creer_bilquad(nquad));
	  /*                                  Q3 je res                              */
	  Quadalloc(&netiq,&narg1,&narg2,&nres);/* allouer memoire aux ingredients   */
	  netiq="";
	  newop=je;
	  narg1=cquad->RES;
	  narg2="";
	  nres="";
	  nquad=creer_quad(netiq,newop,narg1,narg2,nres);/* quadruplet objet (y86)    */
	  main2=concatq(main2,creer_bilquad(nquad));
	  break;
	case St:/* stop                  */
	  /*                                 Q1 St   #quadsource                      */
	  Quadalloc(&netiq,&narg1,&narg2,&nres);/* allouer memoire aux ingredients    */
	  netiq=cquad->ETIQ;
	  newop=halt;
	  narg1="";narg2="";
	  tquad=(char *)malloc((MAXQUAD)*sizeof(char));  /* chaine =  quad courant    */
	  free(nres);                                    /* chaine = #c3a+quad courant*/
	  nres=(char *)malloc((MAXQUAD+5)*sizeof(char));
	  secrire_quad(tquad,cquad);          /* string := quadruplet source          */
	  strcpy(nres,"#trad ");
	  nres=strcat(nres,tquad);
	  nquad=creer_quad(netiq,newop,narg1,narg2,nres);/* quadruplet objet (y86)    */
	  main2=concatq(main2,creer_bilquad(nquad));
	  break;
	default:
	  break;
	};
      cquad=cquad->SUIV;
    }
    /*------------------------------------mul3---------------------------------------*/
  //MUL:				#ssprog: mult de X par Y;stocke res -> 0(%edx)
  nquad=creer_quad("MUL",nop,"","","#ssprog mult:M[M[%edx]]:=X*Y");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //mrmovl   4(%esp),%eax  			# A := X
  nquad=creer_quad("",mrmovl,"4(%esp),","%eax","#A := X");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //mrmovl 	 8(%esp),%ebx			# B := Y
  nquad=creer_quad("",mrmovl,"8(%esp),","%ebx","# B:= Y");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //andl	 %eax,%eax			# si A==0 return 0
  nquad=creer_quad("",andl,"%eax,","%eax","# si A==0 return 0");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //je	 END
  nquad=creer_quad("",je,"END","","");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //SIGN:	 				#si A <= 0 alors (X:= -A,Y:= -B)
  nquad=creer_quad("SIGN",nop,"","","#si A <= 0 alors (X:= -A,Y:= -B)");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //jg 	 MULPLUS			        #cas ou A > 0
  nquad=creer_quad("",jg,"MULPLUS","","#cas ou A > 0");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //irmovl	 0,%ecx
  nquad=creer_quad("",irmovl,"0,","%ecx","");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //subl	 %eax,%ecx
  nquad=creer_quad("",subl,"%eax,","%ecx","");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //rrmovl	 %ecx,%eax
  nquad=creer_quad("",rrmovl,"%ecx,","%eax","");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //rmmovl	 %eax,4(%esp)			#X := -A
  nquad=creer_quad("",rmmovl,"%eax,","4(%esp)","#X := -A");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //irmovl	 0,%ecx
  nquad=creer_quad("",irmovl,"0,","%ecx","");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //subl	 %ebx,%ecx
  nquad=creer_quad("",subl,"%ebx,","%ecx","");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //rrmovl	 %ecx,%ebx
  nquad=creer_quad("",rrmovl,"%ecx,","%ebx","");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //rmmovl	 %ebx,8(%esp)			#Y := -B
  nquad=creer_quad("",rmmovl,"%ebx,","8(%esp)","#Y := -B");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //MULPLUS:	    #Z=M[M[%edx]]:=X*Y  sachant que X >0            
  nquad=creer_quad("MULPLUS",nop,"","","#ssprog X>0->M[M[%edx]]:=X*Y");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //mrmovl   4(%esp),%eax  			# A := X
  nquad=creer_quad("",mrmovl,"4(%esp),","%eax","#A := X");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //andl	 %eax,%eax			# si X==0 return 0
  nquad=creer_quad("",andl,"%eax,","%eax","# si X==0 return 0");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //je	 END
  nquad=creer_quad("",je,"END","","");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //irmovl 1,%esi				# A:=A-1
  nquad=creer_quad("",irmovl,"1,","%esi","# A:=A-1");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //subl %esi, %eax
  nquad=creer_quad("",subl,"%esi,","%eax","");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //mrmovl 8(%esp),%ebx			# B:= Y
  nquad=creer_quad("",mrmovl,"8(%esp),","%ebx","# B:= Y");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //pushl  %ebx				# empiler B, puis A
  nquad=creer_quad("",pushl,"%ebx","","# empiler B, puis A");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //pushl  %eax
  nquad=creer_quad("",pushl,"%eax","","");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //call MULPLUS			 # M[%edx]:= A * B=(X-1) * Y
  nquad=creer_quad("",call,"MULPLUS","","# M[%edx]:= A * B=(X-1) * Y");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //popl  %eax				# depiler A puis B
  nquad=creer_quad("",popl,"%eax","","# depiler A puis B");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //popl  %eax
  nquad=creer_quad("",popl,"%eax","","");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //mrmovl 0(%edx),%eax			# M[%edx]:= M[%edx] + Y
  nquad=creer_quad("",mrmovl,"0(%edx),","%eax","# M[%edx]:= M[%edx] + Y");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //mrmovl 8(%esp),%ebx
  nquad=creer_quad("",mrmovl,"8(%esp),","%ebx","");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //addl %ebx,%eax
  nquad=creer_quad("",addl,"%ebx,","%eax","");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //rmmovl %eax,0(%edx)                 #end MUL(cas X<>0) ret(Z)
  nquad=creer_quad("",rmmovl,"%eax,","0(%edx)","#end MUL(X<>0) ret(Z)");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //ret
  nquad=creer_quad("",ret,"","","");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //END: irmovl 0, %eax                 #end MUL(cas X==0) ret(Z)
  nquad=creer_quad("END",irmovl,"0,","%eax","#end MUL(X==0) ret(Z)");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //rmmovl %eax,	    0(%edx)
  nquad=creer_quad("",rmmovl,"%eax,","0(%edx)","");
  mul3=concatq(mul3,creer_bilquad(nquad));
  //ret
  nquad=creer_quad("",ret,"","","");
  mul3=concatq(mul3,creer_bilquad(nquad));

  /*------------------------------------data4--------------------------------------*/
  /*	  .align 8  #debut zone donnees */
  nquad=creer_quad("",0,".align","8","#debut zone donnees");
  data4=concatq(data4,creer_bilquad(nquad));
  /* Data:                            */
  nquad=creer_quad("Data",0,"","","");
  data4=concatq(data4,creer_bilquad(nquad));
  /*------------------------------------code-y86-----------------------------------*/
  /* bilres=concat(init1,main2,mul3,data4) */
  bilres=concatq(init1,main2);
  bilres=concatq(bilres,mul3);
  bilres=concatq(bilres,data4);
return(bilres);}

/*-------------------------------------------------------------------*/
/*---------------------tests-----------------------------------------*/

/* teste la traduction c3a --> y86 */
void test_trady86(int n, NOE c)
{/* char *etiq;int op;char *arg1; char *arg2;char *res; */
  int i;QUAD qcour;
  BILQUAD bq,bqcour;
  bq.debut=NULL;bq.fin=NULL;
    for(i=0;i<n;i++)
    {qcour=creer_quad(gensym("ET"),Af,gensym("ARG"),gensym("ARG"),gensym("RES"));
      ecrire_quad(qcour);
    };
  for(i=0;i<n;i++)
    {qcour=creer_quad(gensym("ET"),Af,gensym("ARG"),gensym("ARG"),gensym("RES"));
      bqcour=creer_bilquad(qcour);
      bq=concatq(bq,bqcour);
    };
  printf("la biliste des chaines engendrees \n");
  ecrire_bilquad(bq);
  printf("\n");
  bq=imp2quad(c);
  printf("le code a 3 adresses de la commande: \n");
  ecrire_bilquad(bq);
  printf("on interprete le code a 3 adresses: \n");
  semop_ppq(&envrnt,bq);
  bq=quad2y86(bq);
  printf("le code Y86 \n");
  ecrire_bilquad(bq);
  printf("a executer par yas|yis \n");
}

