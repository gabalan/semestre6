/* arbre.c */
#include <assert.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arbre.h"
#include "iimp.tab.h"
/*-------------------------------------------------------------------*/
/* ----------------------------types---------------------------------*/
/*  NOE,PILCOM,ENV : definis dans arbre.h                            */
/*-------------------------------------------------------------------*/
/*---------------------allocation memoire----------------------------*/
char *Caralloc()
{
  return((char *)malloc(sizeof(char)));
}
char *Idalloc()
{
  return((char *)malloc(MAXIDENT*sizeof(char)));
}
NOE Nalloc()
{
  return((NOE)malloc(sizeof(struct noeud)));
}
PILCOM Pilalloc()
{
  return((PILCOM)malloc(sizeof(struct celpilcom)));
}
ENV Envalloc()
{
  return((ENV)malloc(sizeof(struct cellenv)));
}

/*-------------------------------------------------------------------*/
/*---------------------parcours d'arbres-----------------------------*/

void prefix(NOE n)
/* ecrit l'expression n en notation prefixe*/
{ if(n != NULL)
    {printf("%s ",n->ETIQ);
      prefix(n->FG);
      prefix(n->FD);
    };
}

void prefix_code(NOE n)
/* ecrit l'expression n en notation prefixe*/
{ if(n != NULL)
    {printf("%d ",n->codop);
      prefix_code(n->FG);
      prefix_code(n->FD);
    };
}
void infix(NOE n)
/* ecrit l'expression n en notation infixe*/
{ if(n != NULL)
    {printf("%s","(");
      infix(n->FG);
      printf(" %s ",n->ETIQ);
      infix(n->FD);
      printf("%s",")");
    };
}
/*-------------------------------------------------------------------*/
/*-----------------------------environnements------------------------*/

/* initialise l'environnement *prho par  var=0    */
/* la chaine var est copiee dans l' environnement */
int initenv(ENV *prho,char *var)
{ENV pos, newcell;
  pos=rech(var,*prho);/* adresse de la cellule contenant var */
  if (pos == NULL)
    /*on insere var en tete de envrnt*/
    {      newcell=Envalloc();
      newcell->ID=Idalloc();
      strcpy(newcell->ID,var);
      /* newcell->VAL=intalloc(); */
      newcell->VAL=0;
      newcell->SUIV=*prho;
            *prho=newcell;
      return (EXIT_SUCCESS);
    }
  else
    {      return(EXIT_SUCCESS);
    }

}
/* retourne (arg1 op arg2) */
int eval(int op, int arg1, int arg2)
{switch(op)
    {case Pl:
	return(arg1 + arg2);
    case Mo:
      return(arg1 - arg2);
    case Mu:
      return(arg1 * arg2);
    default:
      return(0);
    }
  return(0);
}
 
/* retourne l'adresse de la cellule contenant chaine. NULL si la chaine est absente */
ENV rech(char *chaine, ENV listident)
{if (listident!=NULL)
    {if (strcmp(listident->ID,chaine)==0)
        {return listident;}
      else
	return rech(chaine,listident->SUIV);
    }
  else
    return NULL;
}

/* affecte val a la variable var , dans rho */
int affect(ENV rho, char *var, int val)
{ENV pos;
  pos=rech(var,rho);/* adresse de la cellule contenant var */
  if (pos != NULL)
    {(pos->VAL)=val;
      return(EXIT_SUCCESS);
    }
  else
    return(EXIT_FAILURE);
}

/* affiche l'environnement */  
int ecrire_env(ENV rho)
{ if (rho==NULL)
    {printf("fin d' environnement \n");
      return(EXIT_SUCCESS);}
  else
    {printf("variable %s valeur %d \n",rho->ID,rho->VAL);
      ecrire_env(rho->SUIV); 
      return(EXIT_SUCCESS);
    };
}

/* valeur de var dans rho */
int valch(ENV rho, char *var)
{ENV pos;
  pos=rech(var,rho);/* adresse de la cellule contenant var */
  if (pos != NULL)
    return(pos->VAL);
  else
    return(0);
}

/* valeur d'une expression (non-terminal E) dans un environnement*/
int val(ENV rho, NOE e)
{ if(e != NULL)
    {ENV pos;
      switch(e->codop)
	{case Pl:case Mo:case Mu:                   /* operation binaire */
	    return(eval(e->codop,val(rho,e->FG),val(rho,e->FD)));
	case I:  return (atoi(e->ETIQ));
	case V:
	  {pos=rech(e->ETIQ,rho);/* adresse de la cellule contenant la var */
	    return(pos->VAL);}    /* rho(var)*/
	default: return(EXIT_FAILURE);
	}
    }
  return(EXIT_FAILURE);
}

/*-------------------------------------------------------------------*/	    
/*-----------------------------piles---------------------------------*/

/* on implemente les piles comme des listes (pas de sentinelle) */
/* une pile est appelee par son adresse */

/* affiche la pile de commandes*/ 
void ecrire_pile(PILCOM *ppile)
{ if (*ppile!=NULL)
    {prefix((*ppile)->com);/* affiche le sommet */
      printf("\n");
      ecrire_pile(&(*ppile)->SUIV); 
    }
}
/* retourne (l'adresse d') une pile vide; N.B. ne vaut pas NULL */
PILCOM *pile_vide()
{return((PILCOM *)malloc(sizeof(PILCOM *)));}

/* retourne 1 ssi la pile est vide */
int est_vide(PILCOM *ppile)
{ assert(ppile!=NULL);
return(*ppile==NULL);
}

/* retourne la commande au sommet */ 
NOE sommet(PILCOM *ppile)
{if (*ppile!=NULL)
    return((*ppile)->com); /* retourne un pointeur sur la commande; pas de copie */
  else
    return(NULL);
}

/* depile le sommet (on suppose la pile non vide) */ 
void depile(PILCOM *ppile)
{assert(!est_vide(ppile));
  PILCOM som;
  som=(*ppile);
  *ppile=(*ppile)->SUIV;
  free(som);
}

/* empile le sommet */ 
void empile(NOE com, PILCOM *ppile)
{PILCOM cell;
  cell=Pilalloc();
  cell->com=com;
  cell->SUIV=*ppile;
  *ppile=cell;
}

 /* test des fonctions de base sur les piles de commandes */
void test_piles(NOE com)
{PILCOM *ppile;
  ppile=pile_vide();
  empile(com,ppile);
  empile(com,ppile);
  empile(com,ppile);
  printf("voici la pile: \n");
  ecrire_pile(ppile);
  printf("le sommet de pile est \n");
  prefix(sommet(ppile));
  depile(ppile);
  printf("voici la pile: \n");
  ecrire_pile(ppile);
  depile(ppile);
  depile(ppile);
  printf("la pile est-elle vide ? %d \n",est_vide(ppile));
  }   
/*-------------------------------------------------------------------*/	    
/*-----------------------------semantique de imp---------------------*/

/* UN petit pas de semantique op */
/* fait agir sommet(ppil) sur *rho, met a jour la pile*/
void semop_1pp(ENV rho, PILCOM *ppil)
{ if (!est_vide(ppil))
    {NOE c;char *lhs; int rhs; int cond;
      c=sommet(ppil);
            switch(c->codop)
	{case Mp:/* main program */
	    depile(ppil);
	    empile(c->FG,ppil);
	    break;
	 case Af:
	    lhs= c->FG->ETIQ;
	    rhs= val(rho,c->FD);
	    affect(rho, lhs, rhs);
	    depile(ppil);
	    break;	    
	case Sk: 
	  depile(ppil);
	  break;
	case Se:
	  depile(ppil);
	  empile(c->FD,ppil);
	  empile(c->FG,ppil);
	  break; 
	case If:
	  cond= val(rho,c->FG);
	  depile(ppil);
	  if (cond!=0)                /* cas ou cond !=0 i.e. vrai */ 
	    empile(c->FD->FG,ppil);
	  else                        /* cas ou cond ==0 i.e. faux */
	    empile(c->FD->FD,ppil);
	  break;
	case Wh:
	  cond= val(rho,c->FG);
	  if (cond != 0)           /* on empile le corps */
	    empile(c->FD,ppil);
	  else
	    depile(ppil);
	  break;
	default: break;
	};
      return;
    };
  return;
}

/* semantique op a petits pas */
/* applique un petit pas tant que c'est possible */
void semop_pp(ENV rho, PILCOM *ppil)
{       while (!est_vide(ppil))
      {       semop_1pp(rho,ppil);
             }
    return;
} 
 
/* semantique op a grands pas */
/* fait agir c sur rho, affecte le nouvel environnement a rho*/
void semop_gp(ENV rho, NOE c)
{ if(c != NULL)
    {char *lhs; int rhs; int cond;
      switch(c->codop)
	{case Mp:
	    semop_gp(rho, c->FG);
	    break;
	case Af:
	  lhs= c->FG->ETIQ;
	  rhs= val(rho,c->FD);
	  affect(rho, lhs, rhs);
	  break;	    
	case Sk: break;
	case Se: 
	  semop_gp(rho, c->FG);
	  semop_gp(rho, c->FD);
	  break; 
	case If:
	  cond= val(rho,c->FG);
	  if (cond!=0)                /* cas ou cond !=0 */ 
	    semop_gp(rho, c->FD->FG); 
	  else                        /* cas ou cond !=0 */
	    semop_gp(rho, c->FD->FD);
	  break;
	case Wh:
	  cond= val(rho,c->FG);
	  if (cond != 0)           /* on execute seq(corps,c)*/
	    {semop_gp(rho, c->FD);
	      semop_gp(rho, c); 
	    }
	  break;
	default: break;
	}
    }
  return;
}
