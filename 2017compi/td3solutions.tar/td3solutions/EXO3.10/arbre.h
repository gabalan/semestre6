/* arbre.h */
#ifndef ARBRE_H
#define ARBRE_H 
/* ----------------------------types--------------------------------------------*/
/* commande := arbre abstrait */
typedef struct noeud{
  int codop;
  char *ETIQ;
  struct noeud *FG, *FD;} *NOE;

/* pile de commandes */
typedef struct celpilcom{
             NOE com; /* commande (sous forme d'arbre) */
  struct celpilcom *SUIV;} *PILCOM;

/* environnement := liste de couples (identificateur, entier) */
typedef struct cellenv{
  char *ID;
  int  VAL;
  struct cellenv *SUIV;} *ENV;

/*------------------FONCTIONS ---------------------------------------------------*/
/*------------------parcours d'arbres--------------------------------------------*/
extern int yylex();          /* fonction generee par flex                        */
extern int yyerror();        /* fonction generee par flex/bison                  */
/*---------------------allocation memoire----------------------------------------*/
extern char *Caralloc();     /* retourne un char *                               */
extern char *Idalloc();      /* retourne un tableau de MAXIDENT char             */
extern NOE Nalloc();         /* retourne un NOE                                  */
extern PILCOM Pilalloc();    /* retourne une pile de commandes                   */
extern ENV Envalloc();       /* retourne un ENV                                  */
/*---------------------parcours d'arbres-----------------------------------------*/
extern void prefix(NOE n);   /* ecrit l'expression n en notation prefixe         */
extern void prefix_code(NOE n);/* codes des operations, en notation prefixe      */
extern void infix(NOE n);    /* ecrit l'expression n en notation infixe          */
/*---------------------environnements--------------------------------------------*/
extern int initenv(ENV *prho,char *var);/* initialise l'ident var dans *prho     */
extern int ecrire_env(ENV rho);/* affiche l'environnement                        */
extern int eval(int op, int arg1, int arg2); /* retourne (arg1 op arg2)          */
extern ENV rech(char *chaine, ENV listident);/* retourne la position de chaine   */
extern int affect(ENV rho, char *var, int val);/* affecte val a la variable var  */
extern int valch(ENV rho, char *var); /* valeur de var dans envirnt rho          */
extern int val(ENV rho, NOE e); /* valeur d'une expression dans envirnt rho      */
/*---------------------piles de commandes----------------------------------------*/
extern void ecrire_pile(PILCOM *ppile); /* affiche la pile de commandes          */
extern PILCOM *pile_vide(); /* retourne (l'adresse d') une pile vide             */
extern int est_vide(PILCOM *ppile); /* retourne 1 ssi la pile est vide           */
extern NOE sommet(PILCOM *ppile); /* retourne la commande au sommet              */
extern void depile(PILCOM *ppile);/* depile le sommet                            */ 
extern void empile(NOE com, PILCOM *ppile); /* empile le sommet                  */
extern void test_piles();/* test des fonctions de base sur les piles de commandes*/
/*----------------------semantique de imp----------------------------------------*/
extern void semop_1pp(ENV rho,PILCOM *ppil);  /* Un petit pas de semantique op   */
extern void semop_pp(ENV rho,PILCOM *ppil);   /* semantique op a petits pas      */
extern void semop_gp(ENV rho,NOE c);          /* semantique op a grands pas      */
/* ------------------CONSTANTES -------------------------------------------------*/
#define MAXIDENT 16          /* long max d'un identificateur de variable         */
#define MAXQUAD  5*MAXIDENT  /* long max d'un quadruplet c3a                     */
/*-------------------VARIABLES globales -----------------------------------------*/
extern NOE syntree;          /* arbre syntaxique (y.tab.c)     */
extern ENV envrnt;           /* environnement courant (y.tab.c)*/
extern char ident[MAXIDENT]; /*identificateur courant (y.tab.c)*/
#endif
