#include  <assert.h>
#include  <stdio.h>
#include  <ctype.h>
#include  <math.h>
#include  <stdlib.h>
#include  <string.h>
#include  "tree.h"

/* retourne un arbre */
struct Tree *createTree()
     {return (struct Tree*) malloc (sizeof(struct Tree)); 
     }

/* retourne une chaine de caracteres */
char *Idalloc()
{return ((char *)malloc(MAXL*sizeof(char)));
}

/* affecte les champs de tree par les arguments suivants */
void affecTree(struct Tree *tree,struct Tree *f1,struct Tree *f2,struct Tree *f3, int rg,char *et)
{tree->fils[0]=f1;tree->fils[1]=f2;tree->fils[2]=f3;
  tree->regle=rg;
  tree->etiq=Idalloc();
  strcpy(tree->etiq,et);/* recopie la chaine et */
 }

/* arite en fonction de la regle */
int arit(struct Tree *n)
  {switch(n->regle)
      {case 0:return 0;/* feuille */
       case 1:return 3;
       case 2:return 1;
       case 3:return 3;
       case 4:return 1;
       case 5:return 1;
       case 6:return 2;
       case 7:return 3;
      default:return -1;
      };
  } 

void ecrire_noeud(struct Tree *n)
{printf("%s",n->etiq);
   }

void prefixTree(struct Tree *tree)
/* ecrit tree en notation prefixe */
   {if (tree != NULL)
       {ecrire_noeud(tree);
	 int ar=arit(tree);
	 if (ar != 0)
	   {int i=0;
            /* debug  
             printf("\n printTree ");
             printf("arite=%d \n", ar);
             enddebug */
	     for(i=0; i < ar; i=i+1)
	       {printf("%s",",");
		prefixTree(tree->fils[i]);
	        }
	   };
       };
   }
}

