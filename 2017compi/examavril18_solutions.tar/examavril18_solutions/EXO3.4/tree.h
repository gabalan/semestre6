#ifndef TREE_H
#define TREE_H
/*--------------------------------------------------------------------------*/
/*---------------------------constantes-types-------------------------------*/ 
#define ARMAX 3 /* arite max des arbres de derivation */
#define MAXL 10 /* longueur max d'une etiquette */
struct Tree{
  struct Tree *fils[ARMAX]; /* tableau des fils                             */
  int regle;/* numero de regle de grammaire etiq(noeud) -->etiq(fils)       */
  char *etiq; /* etiquette: non-terminal                                    */
  };
/*--------------------------------------------------------------------------*/
/*----------------------------------fonctions-------------------------------*/ 
extern struct Tree *createTree();/* retourne un struct Tree */
extern char *Idalloc();/* retourne une chaine de longueur MAXL*/
/* affecte les champs de tree par les arguments suivants */
extern void affecTree(struct Tree *tree,struct Tree *f1,struct Tree *f2,struct Tree *f3, int rg,char *et); /* affecte les champs de tree par les arguments suivants   */
extern void ecrire_noeud(struct Tree *n);
extern void prefixTree(struct Tree *tree); /* ecrit tree en notation prefixe */
extern void ecrire_regle(struct Tree *n);/* ecrit " ri" pour la regle i           */
extern void derivTree(struct Tree *tree); /* ecrit la derivation gauche      */
#endif
