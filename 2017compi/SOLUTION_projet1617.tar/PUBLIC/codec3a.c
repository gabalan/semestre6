/* codec3a.c */
#include <assert.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arbre.h"
#include "interp_mp.h"
#include "codec3a.h"
#include "ppascal.tab.h"
/*-------------------------------------------------------------------*/
/* ----------------------------types---------------------------------*/
/* NOE,ENVTY,BILENVTY : definis dans arbre.h                         */
/* QUAD,BILQUAD: definis dans codec3a.h                              */
/*-------------------------------------------------------------------*/
/*---------------------quadruplets-----------------------------------*/
/* retourne une nouvelle etiquette (numeros indep de ceux de gensym) */
char *genetiq()
{static int counter=0;
  char *chaine;char *chcounter;
  chcounter=Idalloc();
  chaine=Idalloc();
  strcpy(chaine,"ET"); 
  sprintf(chcounter,"%d",counter);   /* prefix+chaine(counter)*/
  counter=counter+1;
  strcat(chaine,chcounter);
  return(chaine);
}

/* retourne un quadruplet (avec etiquette etiq) */
QUAD creer_quad(char *etiq,int op,char *arg1,char *arg2,char *res)
{QUAD qd;int lres;
  qd=(struct cellquad *)malloc(sizeof(struct cellquad));
  if (etiq !=NULL)
    {qd->ETIQ=Idalloc();
      strcpy(qd->ETIQ,etiq);}
  qd->OP=op;
  if (arg1 !=NULL)
    {qd->ARG1=Idalloc();
      strcpy(qd->ARG1,arg1);}
  if (arg2 !=NULL)
    {qd->ARG2=Idalloc();
      strcpy(qd->ARG2, arg2);}
  if (res!= NULL)
    {lres=strlen(res);
      qd->RES=(char *)malloc(lres*sizeof(char));
      strcpy(qd->RES,res);}
  return(qd);
}

/* retourne une biliste vide  */
BILQUAD bilquad_vide() 
{BILQUAD bq;
  bq.debut=NULL;bq.fin=NULL;
  return(bq);
}

/* retourne une biliste a un element  */
BILQUAD creer_bilquad(QUAD qd) 
{BILQUAD bq;
  bq.debut=qd;bq.fin=qd;
  return(bq);
}

/* fonction aux  pour la fonction rechbq */
QUAD rechq(char *chaine, QUAD qd)
{QUAD qcour;
  qcour=qd;
  if (qcour!=NULL)
    {if (strcmp(qcour->ETIQ,chaine)==0)
        { 	  return qcour;}
      else
	return rechq(chaine,qcour->SUIV);
    }
  else
    return NULL;
}

/*retourne le quad etiquete par chaine, NULL s'il n'y en a pas */
QUAD rechbq(char *chaine, BILQUAD bq)
{return(rechq(chaine,bq.debut));}


BILQUAD concatq(BILQUAD bq1, BILQUAD bq2)
/* retourne la concatenation; ne detruit pas bqi; ne copie pas *bqi */
/* peut creer une boucle ! */
{BILQUAD bq;
  if (bq1.fin!= NULL)
    if (bq2.debut!=NULL)
       { bq1.fin->SUIV=bq2.debut;
        bq.debut=bq1.debut;
        bq.fin=bq2.fin;
        return(bq);}
    else
      return(bq1);  
  else
    return(bq2);
}

/* retourne bq +  skip */
BILQUAD ajouterskip(BILQUAD bq)
{QUAD nq; BILQUAD nbq;
  nq=creer_quad(genetiq(),Sk,NULL,NULL,NULL);/* instruction skip */
  nbq=creer_bilquad(nq);
  return(concatq(bq,nbq));
}

/* retourne la "forme normale" de bq: dernier quad = skip */  
BILQUAD normal(BILQUAD bq)
{if (bq.fin== NULL)
    {return(ajouterskip(bq));}
  else
    {if (bq.fin->OP!=Sk)        /* pas normal-> on normalise */
	return(ajouterskip(bq));
      else                      /* deja normal */
	return(bq);}
}

/* affiche le quadruplet v1 (pour tests) */
void ecrire_quad1(QUAD qd)
{printf("etiq:%s,op:%s,arg1:%s,arg2:%s,res:%s \n",qd->ETIQ,nomop(qd->OP),qd->ARG1,qd->ARG2,qd->RES);
}

/* affiche le quadruplet (pour generer code); puis saute a la ligne */
void ecrire_quad(QUAD qd)
{ if(strcmp(qd->ETIQ,"") == 0)       /* etiquette= mot vide */
    {printf("%-10s ","");}
  else
    {printf("%-10s:",qd->ETIQ);}
  printf("%-6s ",nomop(qd->OP));
  if (qd->ARG1!=NULL)
    {printf("%-10s",qd->ARG1);}
  else
    {printf("%-10s","");}
  if (qd->ARG2!=NULL)
    {printf("%-10s",qd->ARG2);}
  else
    {printf("%-10s","");}
  if (qd->RES!=NULL)
    {printf("%-10s\n",qd->RES);}
  else
    {printf("\n");}
  }

/* ecrit le quadruplet dans un string; pas de newline             */
void secrire_quad(char *tquad, QUAD qd)
{ char mot[MAXIDENT];
  sprintf(tquad,"%-6s ",nomop(qd->OP));
  if (qd->ARG1!=NULL)
    {sprintf(mot,"%-10s",qd->ARG1);
      strcat(tquad,mot);}
  else
    {sprintf(mot,"%-10s"," ");
      tquad=strcat(tquad,mot);};
    if (qd->ARG2!=NULL)
    {sprintf(mot,"%-10s",qd->ARG2);
      strcat(tquad,mot);}
  else
    {sprintf(mot,"%-10s"," ");
      strcat(tquad,mot);};
    if (qd->RES!=NULL)
    {sprintf(mot,"%-10s",qd->RES);
      strcat(tquad,mot);}
  else
    {sprintf(mot," ");
      strcat(tquad,mot);};
    }

/* affiche la biliste de quad */
void ecrire_bilquad(BILQUAD bq)
{QUAD qcour;
  qcour=bq.debut;
  while(qcour!=NULL)
    {ecrire_quad(qcour);
      qcour=qcour->SUIV;}
}

/*-------------------------------------------------------------------*/
/*------------------------mp-vers-quad-------------------------------*/

/* traduit une (expression ou commande) en biliste de quadruplets */
/* ec est supposee: plate, sans tab, sans fonc, sans const        */
/* met a jour l'environnement (var globale)                       */
BILQUAD mp2quad(BILFON bfon, NOE ec)
{ BILQUAD bilq1, bilq2, bilres;/* trad de: fg, fd, expression, resultat */
  int newop; char *netiq, *netiqf, *nres;        /* nouveaux ingredients */
  char *narg1=NULL;char *narg2=NULL;
  char *nomf=NULL;                               /* nom de fonction      */
  QUAD nquad;                                    /* nouveau quadruplet   */
  bilres=bilquad_vide();                         /* le bilquad resultat  */
    if (ec != NULL)
  /* ec est une COMMANDE */
  switch(ec->codop)
    {case Mp:
      bilq1=mp2quad(bfon,ec->FG);
            /* les ingredients */
      netiq=genetiq();newop=St;narg1=NULL;narg2=NULL;nres=NULL;
      /* le quadruplet final: stop  (pas d'adresse de resultat) */
      nquad=creer_quad(netiq,newop,narg1,narg2,nres);
      bilq2=creer_bilquad(nquad);
      bilres=concatq(bilq1,bilq2);
      break;
     case Af:/* sous-cas:Af(tabconst,NewAr(const)), Af(var,const), Af(var,var)       */
             /* Af(var,op(var,var)), Af(Ind(T,var),var),                             */
      if (((ec)->codop==Af)&& ((ec)->FD->codop==NewAr))
	 /* construction des tableaux constants:                                     */
	 /* connus de l'interpreteur et du compilateur: ADR#,TAL#,TAS#: pas de quad  */
	{;}
      else if (((ec)->codop==Af)&& ((ec)->FG->codop==V) && ((ec)->FD->codop==I))
	{/* Af(var,const)*/
	 /* les ingredients */
	 netiq=genetiq();
         newop=Afc;
	 narg1=Idalloc();
	 strcpy(narg1,ec->FD->ETIQ);/* numeral */
	 narg2=NULL;
	 nres=Idalloc();
	 strcpy(nres,ec->FG->ETIQ);/* adresse d'affectation */
	 /* le quadruplet: ETnum, Afc, const1,NULL,res2  */
         nquad=creer_quad(netiq,newop,narg1,narg2,nres);
         bilres=creer_bilquad(nquad);
	 	}
      else if (((ec)->codop==Af)&& ((ec)->FG->codop==V) && ((ec)->FD->codop==V))
	{/* Af(var,var)*/
	 /* les ingredients */
	 netiq=genetiq();
         newop=Af;
	 narg1=Idalloc();
	 strcpy(narg1,ec->FG->ETIQ);/* variable */
	 narg2=Idalloc();
	 strcpy(narg2,ec->FD->ETIQ);/* variable */
	 nres=NULL;       /* pas de destination */
	 /* le quadruplet: ETnum, Af, var1, var2, NULL  */
         nquad=creer_quad(netiq,newop,narg1,narg2,nres);
         bilres=creer_bilquad(nquad);
	}
      else if (((ec)->codop==Af)&& ((ec)->FG->codop==V))
	{/* Af(var,op(var,var))*/
	 /* les ingredients */
	 netiq=genetiq();
         newop=(ec)->FD->codop;
                  /* narg1= chaine en lhs */
	 narg1=Idalloc();
	 strcpy(narg1,ec->FD->FG->ETIQ);
	 narg1=Idalloc();/* op a un argument a gauche*/
	 strcpy(narg1,ec->FD->FG->ETIQ);
	 narg2=Idalloc();
	 if (ec->FD->FD) /* op est binaire et a un arg droit, sinon est unaire */
	   strcpy(narg2,ec->FD->FD->ETIQ);
	 else
	   strcpy(narg2,"");
         nres=Idalloc();
	 strcpy(nres,ec->FG->ETIQ);
         /* le quadruplet: ETnum, Af, chainevar1,chainevar2,chaineres */
         nquad=creer_quad(netiq,newop,narg1,narg2,nres);
         bilres=creer_bilquad(nquad);
	}
      else if (((ec)->codop==Af)&& ((ec)->FG->codop==Ind))
	{/*Af(Ind(T,var),var)*/
	 /* les ingredients */
	 netiq=genetiq();
         newop=AfInd;
	 narg1=Idalloc();
	 strcpy(narg1,ec->FG->FG->ETIQ);/* tab constant              */
	 narg2=Idalloc();
	 strcpy(narg2,ec->FG->FD->ETIQ);/* index (var)               */
	 nres=Idalloc();
	 strcpy(nres,ec->FD->ETIQ);/* var affectee dans narg1[narg2] */
	 /* le quadruplet: ETnum, AfInd, tab,index,arg  */
         nquad=creer_quad(netiq,newop,narg1,narg2,nres);
         bilres=creer_bilquad(nquad);
	};
      break;	    
    case Sk:
      /* les ingredients */
      netiq=genetiq();newop=Sk;narg1=NULL;narg2=NULL;nres=NULL; 
      /* le quadruplet: skip  (pas d'adresse de resultat) */
      nquad=creer_quad(netiq,newop,narg1,narg2,nres);
      bilres=creer_bilquad(nquad);
      break;
    case Se: 
      bilq1=mp2quad(bfon,ec->FG);
      bilq2=mp2quad(bfon,ec->FD);
      bilres=concatq(bilq1,bilq2);
      break;
    case If:
      bilq1=mp2quad(bfon,ec->FD->FG); /* commande (cas vrai) */
      bilq2=mp2quad(bfon,ec->FD->FD); /* commande (cas faux) */
            bilq2=normal(bilq2);
            /* les ingredients de Q1 */
      netiq=genetiq();newop=Jz;
      narg1=Idalloc();
      strcpy(narg1,ec->FG->ETIQ);
      narg2=NULL;
      nres=bilq2.debut->ETIQ;
      /* le quadruplet Q1 */
      nquad=creer_quad(netiq,newop,narg1,narg2,nres);
      /* nouvelle biliste */
      bilres=creer_bilquad(nquad);
      bilres=concatq(bilres,bilq1);
      /* les ingredients de Q2 */
      netiq=genetiq();newop=Jp;
      narg1=NULL;
      narg2=NULL;
      nres=bilq2.fin->ETIQ;
      /* le quadruplet Q2 */
      nquad=creer_quad(netiq,newop,narg1,narg2,nres);
      /* nouvelle biliste */
      bilres=concatq(bilres,creer_bilquad(nquad));
      bilres=concatq(bilres,bilq2);
      break;
    case Wh:
      /*bilexp=mp2quad(ec->FG);                   l'expression   */
      bilq1=mp2quad(bfon,ec->FD);     /* traduction du corps          */
      bilq1=normal(bilq1);
      /* les ingredients de Q1 */
      netiq=genetiq();newop=Jz;     /* etiquette de Q1           */
      narg1=Idalloc();
      strcpy(narg1,ec->FG->ETIQ);
      narg2=NULL;
      netiqf=genetiq();           /* etiquette fin de traduction */
      nres=netiqf;
      /* le quadruplet Q1: etiq,Jz, */
      nquad=creer_quad(netiq,newop,narg1,narg2,nres);
      /* nouvelle biliste */
      bilres=creer_bilquad(nquad);
      bilres=concatq(bilres,bilq1);
      /* les ingredients de Q2 */
      newop=Jp;
      /* narg1=narg2=NULL; */
      nres=Idalloc();
      strcpy(nres,netiq);
      /* on substitue Q2 a la fin de bilres */
      bilres.fin->OP=newop;
      assert(bilres.fin->ARG1==NULL); /* vrai si bilq1 est normalise */
      assert(bilres.fin->ARG2==NULL);
      bilres.fin->RES=nres;           /* derniere inst de bilres est Jp nres */
      /* les ingredients de Q3 */
      netiq=netiqf;                   /* etiquette de Q3            */
      newop=Sk; narg1=NULL; narg2=NULL; nres=NULL;
      /* le quadruplet Q3: netiqf Sk  */
      nquad=creer_quad(netiq,newop,narg1,narg2,nres);
      /* nouvelle biliste */
      bilres=concatq(bilres,creer_bilquad(nquad));
      break;
    case Ap:
      nomf=Idalloc();
      strcpy(nomf,(ec->FG)->ETIQ);
      LFON posf=rechfon(nomf, bfon.debut);
      BILENVTY bparam=copier_bilenvty(posf->PARAM);     
      BILENVTY blocal=copier_bilenvty(posf->VARLOC); 
      ENVTY pos=bparam.debut;            /* params formels (liste)                 */
      NOE argap;
      int nbparams;/* nombre de params de l'appel (par formels + var locales)      */
      nbparams=0;
      if (pos != NULL)
	{assert(ec->FD->codop==ArgAp);
	 argap=ec->FD;                /* param d'appel(arbre)                      */
	 while (pos && argap)        /* param formels := params d'appel            */
	   { /* ajouter le bilquad (etiq, Param,pos->ETIQ,argap->FG->ETIQ,NULL)    */
	     netiq=genetiq();
	     if (argap->FG->codop==I)
	       newop=Paramc;
	     else
	       {assert(argap->FG->codop==V);
		 		 newop=Param;};
	     narg1=Idalloc();
	     strcpy(narg1,pos->ID);       /* nom du parametre formel      */
	     narg2=Idalloc();
	     strcpy(narg2,argap->FG->ETIQ);/* argument: nomvar ou numeral */
	     nres="";
	     nquad=creer_quad(netiq,newop,narg1,narg2,nres);
	     /* nouvelle biliste */
             bilres=concatq(bilres,creer_bilquad(nquad));
	     pos=pos->SUIV; argap=argap->FD;nbparams++;
	   };
	}
	 /* idem avec VARLOC et la valeur 0 */
      pos=blocal.debut;            /* var locales   (liste)                        */
      if (pos != NULL)
	while (pos)        /* param formels := params d'appel                      */
	  {netiq=genetiq();
	   newop=Paramc;
	   narg1=Idalloc();
	   strcpy(narg1,pos->ID);/* nom du parametre formel         */
	   narg2=Idalloc();
	   strcpy(narg2,"0");/* argument:= val par defaut=0         */
	   nres="";
	   nquad=creer_quad(netiq,newop,narg1,narg2,nres);
	   /* nouvelle biliste */
           bilres=concatq(bilres,creer_bilquad(nquad));
	   /* ajouter le bilquad (etiq, Param,pos->ETIQ,"0",NULL)   */ 
	   pos=pos->SUIV;nbparams++;
	   };
      /* appel de la proc */
      netiq=genetiq();
      newop=Call;
      narg1=nomf;/* nom de la proc         */
      narg2=Idalloc();
      sprintf(narg2,"%d",nbparams); 
      nres="";
      nquad=creer_quad(netiq,newop,narg1,narg2,nres);
      bilres=concatq(bilres,creer_bilquad(nquad));
      break;
    default: break;
    };
    return(bilres);
}

/* traduit un programme (MP + liste de procedures)  en biliste de quadruplets */
BILQUAD mp2quad_prog(BILFON bfon, NOE corps)
{BILQUAD bilres,bilq1;
  int newop; char *netiq, *nres;        /* nouveaux ingredients */
  char *narg1=NULL;char *narg2=NULL;
  QUAD nquad;
  /* traiter le corps */
     bilres=mp2quad(bfon,corps);
  /* traiter les fonctions */
  LFON pfon= bfon.debut; /* pointe sur la fonction courante */
  while (pfon)
    {/* entete de pro  */
     netiq=Idalloc();
     strcpy(netiq,pfon->ID);/* nom de la proc         */
     newop=Sk;
     narg1="";
     narg2="";
     nres="";
     nquad=creer_quad(netiq,newop,narg1,narg2,nres);
     bilres=concatq(bilres,creer_bilquad(nquad));
     /* traiter la pro */ 
     bilq1= mp2quad(bfon,pfon->CORPS);   /* traiter la pro */
     bilres=concatq(bilres,bilq1);
     pfon=pfon->SUIV;
     /* return */
     netiq=genetiq();
     newop=Ret;
     narg1="";
     narg2="";
     nres="";
     nquad=creer_quad(netiq,newop,narg1,narg2,nres);
     bilres=concatq(bilres,creer_bilquad(nquad));
     };
  return(bilres);
  }

/*-------------------------------------------------------------------*/	    
/*-----------------------------semantique de C3A---------------------*/
/* interprete c3a, en partant de ins, dans les env rho_*             */
/* semantique a grands pas                                           */
void  semop_c3a(BILENVTY rho_gb, BILENVTY rho_lc,BILENVTY rho_p, QUAD ins, BILQUAD c3a)
{ int val1, val2, res, numarg;
  ENVTY adenv1,adenv2, adenv, adres;               /* une adresse dans un env      */
  QUAD nins;                                       /* pointe une instruction de c3a*/
  char *nomf;
 
  type tint=creer_type(0,0,T_int);
    while (ins!=NULL)
    switch(ins->OP)/* operateur du quadruplet */
      {case Pl:case Mo:case Mu:case And:case Or:case Lt:case Eq:
	 /* operation binaire */
	  	  adenv1= rechty2(ins->ARG1, rho_gb.debut, rho_lc.debut);
	  	  val1=adenv1->VAL;/* val de ARG1 */
	  	  adenv2= rechty2(ins->ARG2, rho_gb.debut, rho_lc.debut);
	  	  val2=adenv2->VAL;/* val de ARG2 */
	  	  res=eval(ins->OP,val1,val2);
	  	  /* affecter res a ins->RES dans env */
	  affectb(rho_gb,rho_lc, ins->RES, res);
	  	  ins=ins->SUIV;
	  /* semop_c3a(rho_gb,rho_lc,rho_p,nins,c3a);*/
	  break;
        case Not:
	  /* operation unaire */
	  	  adenv1= rechty2(ins->ARG1, rho_gb.debut, rho_lc.debut);
	  	  val1=adenv1->VAL;/* val de ARG1 */
	  	  res=eval(ins->OP,val1,val1);
	  affectb(rho_gb,rho_lc, ins->RES, res);
	  ins=ins->SUIV;
	  break;
	case Ind:/* evaluation d'un index (eval(Ind,*,*) est incorrecte ici )*/
	  /* Arg1[Arg2] --> dest */
	  	  adenv2= rechty2(ins->ARG2, rho_gb.debut, rho_lc.debut);
	  val2=adenv2->VAL;
	  if (strcmp(ins->ARG1,"TAS#")==0)
	    res = TAS[val2];
	  else if (strcmp(ins->ARG1,"TAL#")==0)
	    res= TAL[val2];
	  else if (strcmp(ins->ARG1,"ADR#")==0)
	    res= ADR[val2];
	  else /* tableau inconnu */
	    assert(false);
	  affectb(rho_gb,rho_lc, ins->RES, res);
	  ins=ins->SUIV;
	  break;
	case AfInd:/* affectation a un index */
	  /* Arg1[Arg2] :=  res */
	  	  adres= rechty2(ins->RES, rho_gb.debut, rho_lc.debut);
	  res= adres->VAL;
	  adenv2= rechty2(ins->ARG2, rho_gb.debut, rho_lc.debut);
	  val2=adenv2->VAL;
	  if (strcmp(ins->ARG1,"TAS#")==0)
	    TAS[val2] = res;
	  else if (strcmp(ins->ARG1,"TAL#")==0)
	    TAL[val2]=res;
	  else if (strcmp(ins->ARG1,"ADR#")==0)
	    ADR[val2]=res;
	  else /* tableau inconnu */
	    assert(false);
	  ins=ins->SUIV;
	  break;
	case Af:/* affectation var -> var    */
	  adenv2= rechty2(ins->ARG2, rho_gb.debut, rho_lc.debut);
	  	  affectb(rho_gb, rho_lc, ins->ARG1, adenv2->VAL);
	  	  ins=ins->SUIV;
	  /* semop_c3a(rho_gb,rho_lc,rho_p,nins,c3a);*/
	  break;
	case Afc:/* affectation const -> var */
	  val1=atoi(ins->ARG1);
	  	  affectb(rho_gb, rho_lc, ins->RES, val1);
	  	  ins=ins->SUIV;
	  /* semop_c3a(rho_gb,rho_lc,rho_p,nins,c3a);*/
	  break;
	case Sk:/* skip                      */
	  	  ins=ins->SUIV;
	  break;
	case Jp:/* saut inconditionnel       */
	  	  ins=rechbq(ins->RES,c3a);
	  break;
	case Jz:/* saut si arg1 == 0        */
	  	  adenv1= rechty2(ins->ARG1, rho_gb.debut, rho_lc.debut);
	  val1=adenv1->VAL;/* val de ARG1 */
	  	  if (val1==0)
	    {ins=rechbq(ins->RES,c3a);
	    }
	  else	    
	    {ins=ins->SUIV;
	    };
	  break;
	case St: /* stop */
	  ins=NULL;
	  	  break;
        case Ret: /* return */
	  ins=NULL;
	  	  break;
	case Param:     /* empiler un parametre  var dans  rho_p*/
	  	  ajout_var(&rho_p,ins->ARG1, tint);
	  adenv2=rechty2(ins->ARG2, rho_gb.debut, rho_lc.debut);
	  val2=adenv2->VAL;/* val de ARG2 dans l'environnement*/
	  affectb(rho_gb,rho_p,ins->ARG1,val2);
	  ins=ins->SUIV;
	  break;
	case Paramc: /* empiler un parametre numeral  dans rho_p*/
	  	  ajout_var(&rho_p,ins->ARG1,tint);
	  val2=atoi(ins->ARG2);/* val de ARG2 (numeral)*/
	  affectb(rho_gb,rho_p,ins->ARG1,val2);
	  ins=ins->SUIV;
	  break;
	case Call:   /* appel de sous-programme                 */
	  	  nomf=Idalloc();
	  strcpy(nomf,ins->ARG1);/* nom du sous-prog            */
	  numarg=atoi(ins->ARG2);/* nombre de parametres        */
	  nins=rechbq(nomf,c3a); /* debut du sous-prog          */
	  /* les nouveaux environnements */
	  BILENVTY newrho_lc= bilenvty_vide();
	  BILENVTY newrho_p= bilenvty_vide();
	  /* depiler rho_p, empiler  dans newrho_lc, numarg fois                 */
	  adenv=rho_p.debut;   /* pointe sur le parametre au sommet              */
	  while (numarg >0)
	    {assert(adenv!=NULL);/* sinon: moins de param que numarg             */
	     ajout_var(&newrho_lc, adenv->ID, tint);/* empile le param dsnewrho_lc*/
	     newrho_lc.debut->VAL=adenv->VAL;
	     adenv=adenv->SUIV;
	     numarg--;
	    }
	  rho_p.debut=adenv;
	  /* sauter au sousprog */
	  semop_c3a(rho_gb, newrho_lc,newrho_p,nins,c3a);
	  /* au retour du sous prog: continuer */
	  ins=ins->SUIV;
	  break;
	default:
	  	  ins=NULL;
	  break;
	};/* fin switch */
  /* fin while */
    return; /* fin de semop */
}

extern void  semop_c3a_prog(BILENVTY rho_gb, BILQUAD c3a)/* interprete c3a, 
rho_gb contient les variables globales avec leur valeur par defaut: 0 */
{return;}
  


