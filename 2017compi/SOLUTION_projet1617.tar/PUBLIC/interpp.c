/* interpp.c */

 #include <stdio.h>
 #include <ctype.h>
 #include <string.h>
 #include "arbre.h"
 #include "ppascal.tab.h"
 #include "ppascal.h"
 #include "interp_mp.h"
 #include "anasem.h"
 #include "codec3a.h"

int main(int argn, char **argv)
/* l'interpreteur */
{
  yyparse();
  init_memoire();
  BILENVTY benvloc=bilenvty_vide();
  semop_gp(benvty,benvloc,blfonctions,syntree);
  printf("Les variables globales apres exec:\n");
  printf("------------------------:\n");
  ecrire_bilenvty(benvty); printf("\n");
  ecrire_memoire(10,10,40);
  return(1);
  }


