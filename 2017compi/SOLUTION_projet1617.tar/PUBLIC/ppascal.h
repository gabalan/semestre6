/* ppascal.h */
#ifndef PPASCAL_H
#define PPASCAL_H 
/* ------------------VARIABLES GLOBALES -------------------------*/
extern   NOE syntree;          /* commande  globale              */
extern   BILENVTY benvty;      /* environnement global           */
extern   BILFON blfonctions;   /* biliste des fonctions globale  */
/* -------------------------------- -----------------------------*/
#endif
