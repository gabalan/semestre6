/* compi_interc3a.c */
 #include <stdio.h>
 #include <ctype.h>
 #include <string.h>
 #include "arbre.h"
 #include "ppascal.tab.h"
 #include "ppascal.h"
 #include "interp_mp.h"
 #include "anasem.h"
 #include "codec3a.h"

/* Traduction des progs PP en C3A puis execution du C3A */
int main(int argn, char **argv)
{ yyparse();
  //traduction de PP en MP
 applat_prog(&benvty,blfonctions,&syntree);
 chasse_tab_prog(&benvty,blfonctions,&syntree,10,5);
 chasse_fonc_prog(&benvty,blfonctions,&syntree);
 chasse_const_prog(&benvty,blfonctions,&syntree);
 //traduction de MP en C3A 
 BILQUAD bq = mp2quad_prog(blfonctions,syntree);
 printf("\n le programme C3A \n");
 ecrire_bilquad(bq);
 //l'interpreteur C3A 
 printf("\n maintenant on lance semop_c3a \n");
 BILENVTY rho_lc=bilenvty_vide() ;
 BILENVTY rho_p=bilenvty_vide();
 semop_c3a(benvty,rho_lc,rho_p, bq.debut, bq);
 //affichage des resultats
 printf("envirnts d'arrivee \n");
 ecrire_bilenvty(benvty);
 printf("\n");
 ecrire_bilenvty(rho_lc);
 printf("\n");
 ecrire_bilenvty(rho_p);
}

