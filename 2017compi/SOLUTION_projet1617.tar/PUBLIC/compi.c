/* compi.c */
 #include <stdio.h>
 #include <ctype.h>
 #include <string.h>
 #include "arbre.h"
 #include "ppascal.tab.h"
 #include "ppascal.h"
 #include "interp_mp.h"
 #include "anasem.h"
 #include "codec3a.h"

/* traduction de PP vers MP puis vers C3A */  
int main(int argn, char **argv)
 {yyparse();
 printf("Le PROG INITIAL PP:\n");
 ecrire_prog(benvty,blfonctions,syntree);
 //traduction en MP, 4 etapes
  applat_prog(&benvty,blfonctions,&syntree);
  chasse_tab_prog(&benvty,blfonctions,&syntree,10,5);
  chasse_fonc_prog(&benvty,blfonctions,&syntree);
  chasse_const_prog(&benvty,blfonctions,&syntree);
 //traduction en C3A
 BILQUAD bq = mp2quad_prog(blfonctions,syntree);
 printf("\n Le PROG TRADUIT C3A: \n");
 ecrire_bilquad(bq);
}


