/* interp_mp.h */
#ifndef INTERP_MP_H
#define INTERP_MP_H
/*-------------------------------------------------------------------------------*/
/* ----------------------------types---------------------------------------------*/
/*  NOE,ENVTY,BILENVTY  : definis dans arbre.h                                   */
/*  PILCOM     : defini dans interp_mp.h                                         */
/*----------------------semantique de ppascal------------------------------------*/
/* initialisation  memoire                                                       */
void init_memoire();/* initialise le tas: TAS, ADR, TAL                          */
/* decrit la memoire: ADR, TAL, TAS */
void ecrire_memoire(int maxadr, int maxtal, int maxtas);
/* semantique op a grands pas des expressions */  
extern int semval(BILENVTY rho_gb, BILENVTY rho_lc,BILFON bfon,NOE e);
/*semantique op a grdspas des commandes                                          */
extern void semop_gp(BILENVTY rho_gb, BILENVTY rho_lc, BILFON bfon,NOE c);
/*----------------------ppascal--vers--mpascal-----------------------------------*/
extern char *gensym(char *prefix); /* fabrique de nouvelles chaines              */
/* applatit les expressions                                                      */
extern void applat_exp(BILENVTY *rho, NOE *c);
/* applatit les commandes                                                        */
extern void applat_com(BILENVTY *rho, NOE *c);
/* applatit les commandes dans le programme                                      */
extern void applat_prog(BILENVTY *rho, BILFON bfon, NOE *corps);
/* chasse les tableaux dynamiques dans c                                         */
extern void chasse_tab(BILENVTY *rho, NOE *c);
/* chasse les tableaux dynamiques dans le programme                              */
extern void chasse_tab_prog(BILENVTY *rho, BILFON bfon, NOE *corps,int ttas, int tadr);
/* transforme chaque fonction en procedure                                       */  
extern void chasse_fonc_prog(BILENVTY *rho_gb, BILFON bfon, NOE *corps);
/* transforme chaque constante en variable dans les expr de hauteur 1            */  
extern void chasse_const_prog(BILENVTY *rho_gb, BILFON bfon, NOE *corps);
/*---------------------VARIABLES globales ---------------------------------------*/
extern NOE syntree;          /* arbre syntaxique                      (y.tab.c)  */
extern int TAS [TAILLEMEM];  /* le tas; (NIL=0); "vraies" adresses >=1(y.tab.c)  */
extern int ADR[TAILLEADR];   /* ADR[i]=adresse dans le tas du tab i              */
extern int TAL[TAILLEADR];   /* TAL[i]=taille du tab i                           */
extern int ptasl;            /* premiere place libre dans TAS[]                  */
extern int padrl;            /* premiere place libre dans ADR[]                  */
#endif
