/* analysepp.c */
 #include <stdio.h>
 #include <ctype.h>
 #include <string.h>
 #include "arbre.h"
 #include "ppascal.h"
 #include "ppascal.tab.h"
 #include "anasem.h"
 
/* analyse lexicale, syntaxique puis semantique */
int main(int argn, char **argv)
{yyparse();
  ecrire_prog(benvty,blfonctions,syntree);
  type terr=creer_type(0,0,T_err);
  type tcom= creer_type(0,0,T_com);
  if (type_eq(syntree->typno,terr))
    printf("erreur de typage");
  else if (type_eq(syntree->typno,tcom))
    printf("programme bien type");
  else
    printf("attention: typage incomplet");
  return(1);
}
