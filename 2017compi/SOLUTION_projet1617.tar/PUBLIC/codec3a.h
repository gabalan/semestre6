/* codec3a.h */
#ifndef CODEC3A_H
#define CODEC3A_H 
/* ----------------------------types--------------------------------------------*/
/* biliste de quadruplets etiquetes (stocke C3A ou Y86 )*/
typedef struct cellquad{
  char *ETIQ;
  int  OP;
  char *ARG1, *ARG2, *RES;
  struct cellquad *SUIV;} *QUAD;

typedef struct{
  QUAD debut;
  QUAD fin;}BILQUAD;
/*---------------------quadruplets ----------------------------------------------*/
char *genetiq();/*retourne une nouvelle etiquette(compteur <> de celui de gensym)*/
extern QUAD creer_quad(char *etiq,int op,char *arg1,char *arg2,char *res);
extern BILQUAD bilquad_vide() ;                    /* retourne une biliste vide  */
extern BILQUAD creer_bilquad(QUAD qd); /* retourne une biliste  a un element     */
extern QUAD rechbq(char *chaine, BILQUAD bq);/*ret le quad etiquete par chaine   */
extern BILQUAD normal(BILQUAD bq);/* retourne la f.n. de bq: skip a la fin       */ 
extern BILQUAD concatq(BILQUAD bq1, BILQUAD bq2);/* retourne la concatenation    */
extern void ecrire_quad(QUAD qd); /* affiche le quadruplet                       */
extern void secrire_quad(char *tquad,QUAD qd); /* ecrit le quadruplet dans tquad */
extern void ecrire_bilquad(BILQUAD bq); /* affiche la biliste de quadruplets     */
/*---------------------de-mp-vers-C3A--------------------------------------------*/
extern BILQUAD mp2quad(BILFON bfon,NOE ec); /* traduit une com en quadruplets C3A*/
/* traduit un programme (MP + liste de procedures)  en biliste de quadruplets */
extern BILQUAD mp2quad_prog(BILFON bfon, NOE corps);
/*---------------------semantique de C3A-----------------------------------------*/
extern void  semop_c3a(BILENVTY rho_gb, BILENVTY rho_lc, BILENVTY rho_p, QUAD ins, BILQUAD c3a);/* interprete c3a, en partant de ins, dans les env rho_* */
extern void  semop_c3a_prog(BILENVTY rho_gb, BILQUAD c3a);/* interprete c3a, 
rho_gb contient les variables globales avec leur valeur par defaut: 0 */
/*---------------------test------------------------------------------------------*/
extern void test_tradc3a(BILENVTY bty, int n, NOE c);/* teste la trad mp --> c3a  */
#endif
