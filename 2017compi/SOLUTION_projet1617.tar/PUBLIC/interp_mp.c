#include <assert.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arbre.h"
#include "ppascal.tab.h"
#include "interp_mp.h"

/*-------------------------------------------------------------------*/
/* ----------------------------types---------------------------------*/
/*  NOE,ENVTY,BILENVTY  : definis dans arbre.h                       */
/*  PILCOM     : defini dans interp_mp.h                             */
/*-------------------------------------------------------------------*/
/* ------------------VARIABLES GLOBALES ------------------------------*/
/* le tas; (NIL=0); "vraies" adresses >=1                             */
int TAS[TAILLEMEM];
/* ADR[i]=adresse dans le tas du tab i                                */
int ADR[TAILLEADR];
/* TAL[i]=taille du tab i                                             */
int TAL[TAILLEADR];  
int ptasl=1; /* premiere place libre dans TAS[]                       */
int padrl=1; /* premiere place libre dans ADR[]                       */
/*--------------------------------------------------------------------*/
/* ----------------------traitement--memoire--------------------------*/
void init_memoire()
{int i=0;
while (i < TAILLEMEM)
  TAS[i++]=0;
i=0;
while (i < TAILLEADR)
  {ADR[i++]=0;
   TAL[i]=0;
  }
}
/* decrit la memoire: */
/* ADR[i]: adresse du tableau i dans le TAS */
/* TAL[i]: taille du tableau i; de ADR[i] a ADR[i] + TAL[i] */
/* TAS: tableau (statique) contenant tous les tableaux (dynamiques) */
void ecrire_memoire(int maxadr, int maxtal, int maxtas)
{int i;
 printf("Le tableau ADR:\n");
 printf("------------------------:\n");
 for(i=0; i < maxadr;i++)
   printf("%d:",ADR[i]);
 printf("\n");
 printf("Le tableau TAL:\n");
 printf("------------------------:\n");
 for(i=0; i < maxadr;i++)
   printf("%d:",TAL[i]);
 printf("\n");
 printf("Le tableau TAS:\n");
 printf("------------------------:\n");
 for(i=0; i < maxtas;i++)
   printf("%d:",TAS[i]);
 printf("\n");
 return;
}
/*--------------------------------------------------------------------*/	    
/*---------------semantique de pseudo-pascal--------------------------*/
/* N.B.allocation dynamique de tableaux; mais pas de ramasse-miettes! */

/* semantique op a grands pas des expressions                         */
/* fait agir e sur (rho_gb,rho_lc), les  modifie, retourne val(e)     */
int semval(BILENVTY rho_gb,BILENVTY rho_lc,BILFON bfon,NOE e) 
{ if(e != NULL)
    {ENVTY pos; char *nomf;LFON posf; BILENVTY bparam,blocal, newrho_lc;
      NOE exp;int res,taille;
            switch(e->codop)
	{case true:
	   return(1);
	 case false:
	   return(0);
	 case Ind:
	   {int tab=semval(rho_gb,rho_lc,bfon,e->FG);        /* adresse du tableau    */
	   int ind=semval(rho_gb,rho_lc,bfon,e->FD);         /* index dans le tableau */
	   return(TAS[ADR[tab]+ind]);
	   }
	  case Pl:case Mo:case Mu:case And:case Or:case Lt:case  Eq:/* op binaire      */
	    return(eval(e->codop,semval(rho_gb,rho_lc,bfon,e->FG),semval(rho_gb,rho_lc,bfon,e->FD)));
	case Not:                                            /* operation unaire      */
	  return(eval(e->codop,semval(rho_gb,rho_lc,bfon,e->FG),0));
	case I:
	  {
	  	  /* constante int */
	  if (((e->typno).TYPEF) == T_int)
	      {	       return (atoi(e->ETIQ));}
	  else if (strcmp(e ->ETIQ,"true")==0)
	    return(1);
	  else if (strcmp(e ->ETIQ,"false")==0)
	    return(0);
	  else return(0);
	  }
	case V:                         /* variable                   */
	  {pos=rechty(e->ETIQ,rho_lc.debut);  
	    if (pos!=NULL)
	      {	       return(pos->VAL);          /* rho_lc(var)                */
	       	      }
	  else
	    {pos=rechty(e->ETIQ,rho_gb.debut);
	      	     return(pos->VAL);}         /* rho_gb(var)                */
	     }
	case Ap:                        /* appel fonction             */
	  {nomf= (e->FG)->ETIQ;
	   posf=rechfon(nomf,bfon.debut);
           	   bparam=copier_bilenvty(posf->PARAM);
           	   blocal=copier_bilenvty(posf->VARLOC); 
	   pos=bparam.debut;            /* param formel (liste)                       */
	   if (pos != NULL)
	     {assert(e->FD->codop==ArgAp);
	       exp=e->FD;                /* param d'appel(arbre)                      */
	       while (pos && exp)        /* param formels := params d'appel           */
	         {pos->VAL=semval(rho_gb,rho_lc,bfon,exp->FG);
                  		  pos=pos->SUIV; exp= exp->FD;
                  		 };
	     };
	    newrho_lc= concatty(bparam,blocal);/* params:OK, blocal: val_init ??      */
	    semop_gp(rho_gb,newrho_lc,bfon,posf->CORPS);
	    res= valchty(newrho_lc.debut,nomf);/* resultat:= var homonyme             */
	    return(res);
	  }
	case NewAr:                                /* creation tableau                */
	  {taille=semval(rho_gb,rho_lc,bfon,e->FD);/* taille du tableau               */
	    res=padrl;
	    ADR[res]=ptasl;
	    TAL[res]=taille;
	    padrl++;ptasl+=taille;     /* mise a jour allocateur  memoire              */
            	    return(res);
	  }
	default: return(EXIT_FAILURE);  /* codop inconnu au bataillon */
	  }
	}
  else
    return(EXIT_FAILURE);
}

/* semantique op a grands pas des commandes                      */
/* fait agir c sur (rho_gb,rho_lc), les  modifie                 */
void semop_gp(BILENVTY rho_gb, BILENVTY rho_lc, BILFON bfon, NOE c)
{ENVTY pos; char *nomf;LFON posf; BILENVTY bparam,blocal, newrho_lc;
 NOE exp;char *lhs; int rhs; int cond;
 if(c != NULL)
    {switch(c->codop)
       {case Mp:
	    semop_gp(rho_gb, rho_lc, bfon, c->FG);
	    break;
	case Af:
	  	  if (c->FG->codop==V)        /* affectation a une variable */
	    {lhs= c->FG->ETIQ;
	     printf("lhs vaut %s \n",lhs);
	     rhs= semval(rho_gb, rho_lc, bfon, c->FD);
	     printf("rhs vaut %d \n",rhs);
	     affectb(rho_gb,rho_lc, lhs, rhs);
	    }
	  else
	    {assert(c->FG->codop==Ind);/* affectation a un tableau */
	     int tabl= semval(rho_gb, rho_lc, bfon, c->FG->FG);
	     int index=semval(rho_gb, rho_lc, bfon, c->FG->FD);
	     rhs=semval(rho_gb, rho_lc, bfon, c->FD);
	     TAS[ADR[tabl]+index]=rhs;
	     /*TODO: tester que index < taille */
	    }
	  break;	    
	case Sk: break;
	case Se: 
	  semop_gp(rho_gb, rho_lc, bfon, c->FG);
	  semop_gp(rho_gb, rho_lc, bfon, c->FD);
	  break; 
	case If:
	  cond= semval(rho_gb, rho_lc, bfon,c->FG);
	  if (cond!=0)                /* cas ou cond !=0 */ 
	    semop_gp(rho_gb, rho_lc, bfon, c->FD->FG); 
	  else                        /* cas ou cond ==0 */
	    semop_gp(rho_gb, rho_lc, bfon, c->FD->FD);
	  break;
	case Wh:
	  cond= semval(rho_gb, rho_lc, bfon,c->FG);
	  if (cond != 0)           /* on execute seq(corps,c)*/
	    {semop_gp(rho_gb, rho_lc, bfon, c->FD);
	      semop_gp(rho_gb, rho_lc, bfon, c); 
	    }
	  break;
	case Ap:
	  {nomf= (c->FG)->ETIQ;
	   posf=rechfon(nomf, bfon.debut);
	   bparam=copier_bilenvty(posf->PARAM);     
	   blocal=copier_bilenvty(posf->VARLOC); 
	   pos=bparam.debut;            /* param formel (liste)                       */
	   if (pos != NULL)
	     {assert(c->FD->codop==ArgAp);
	       exp=c->FD;                /* param d'appel(arbre)                      */
	       while (pos && exp)        /* param formels := params d'appel           */
	         {pos->VAL=semval(rho_gb,rho_lc,bfon,exp->FG);
		   pos=pos->SUIV; exp= exp->FD;
		 };
	     };
	    newrho_lc= concatty(bparam,blocal);/* params:OK, blocal: val_init ??      */
	    semop_gp(rho_gb,newrho_lc,bfon,posf->CORPS);
	  };
	  break;
	default: break;
	}
    };
return;
}
/*-------------------------------------------------------------------------------*/
/*----------------------ppascal--vers--mpascal-----------------------------------*/
/* retourne une nouvelle chaine */
char *gensym(char *prefix)
{static int counter=0;
  char *chaine;char *chcounter;
  chcounter=Idalloc();
  chaine=Idalloc();
  strcpy(chaine,prefix); 
  sprintf(chcounter,"%d",counter);   /* prefix+chaine(counter)*/
  counter=counter+1;
  strcat(chaine,chcounter);
  return(chaine);
}

/* test de gensym */
void test_constantes(int n)
{char *ident;int i=0;
  for(i=0;i<n;i++)
    {ident=gensym("CONS");
      printf("%s \n",ident);
    }
}

/* adresse du resultat de la commande  c                              */
/* c est l'applatissement d'une expression                            */
/* soit V,I,true,false,  soit Se(lhs,Af(adresse,rhs))                 */
char *adresse(NOE c)
{ char *res=Idalloc();
  int op;/* operateur racine de c */
  if (c == NULL) return NULL; 
  op=c->codop;
  if (est_feuille(c))                  /* variable ou constante */
    strcpy(res,c->ETIQ);
  else if (op == Se)       /* sequence terminee par affectation */
    {assert(c->FD != NULL);
     assert(c->FD->codop=Af);
     strcpy(res,c->FD->FG->ETIQ);
    }
  else strcpy(res,"err");  /* erreur      */
  return(res);
}
/* corps               de la commande  c               */
/* c est l'applatissement d'une expression             */
/* soit V soit Se(lhs,Af(adresse,rhs))                 */
/* renvoie: soit  NULL soit lhs                        */
NOE corps(NOE c)
{ NOE res;
  int op;/* operateur racine de c */
  if (c == NULL) return NULL;
  op=c->codop;
  if (est_feuille(c))               /* variable    ou constante */
    res=NULL;
  else if (op == Se)       /* sequence terminee par affectation */
    {assert(c->FD != NULL);
     assert(c->FD->codop=Af);
     res=c->FG;
    }
  else assert(false);       /* erreur      */
  return(res);
}


/* c est l'applatissement d'une expr                                            */
/* c= feuille ou c=Se(cg,Af(dest,op(resg,resd))), avec resg,resd feuilles           */
/* retourne feuille ou retourne op(resg,resd)                                       */
NOE exp_plate(NOE c)
{ NOE res;
  int op; /* operateur racine de c */                 
  if (c == NULL)
    return NULL;
  op=c->codop;
  if (est_feuille(c))         /* variable ou constante */
    res=c;
  else if (op == Se)   /* sequence  terminee par affectation       */
    {assert(c->FD != NULL);
     assert(c->FD->codop==Af);
     assert (c->FD->FD != NULL);
     assert((c->FD->FD->codop != V)&&(c->FD->FD->codop != I));/* hauteur 1 exacte*/
     res=c->FD->FD;
    }
  else                  /* cas impossible si c est correcte       */
    assert(false);
  return(res);
}

/* c est l'applatissement d'une expr                                            */
/* c= feuille ou c=Se(cg,Af(dest,op(resg,resd))), avec resg,resd feuilles       */
/* retourne NULL ou retourne Af(dest,op(resg,resd))                             */
NOE com_plate(NOE c)
{ NOE res;
  int op; /* operateur racine de c */                 
  if (c == NULL)
    return NULL;
  op=c->codop;
  if (est_feuille(c))         /* variable ou constante */
    res=NULL;
  else if (op == Se)   /* sequence  terminee par affectation       */
    {assert(c->FD != NULL);
     assert(c->FD->codop==Af);
     res=c->FD;
    }
  else                  /* cas impossible si c est correcte       */
    assert(false);
  return(res);
}

/* (cg,resg), (cd,resd) traduisent des exprs;                                    */
/* on applique op a ces deux expr                                                */
/* retourne Se(crps,Af(dest,op(resgN,resdN)))                                 */
/* version simplifiee si cg==NULL ou cd ==NULL   (peut-etre cg==cd==NULL)        */
NOE comb_exp(int op,type top,NOE crps,NOE resgN,NOE resdN,char *dest)
{ NOE N1,N10,N11,res;
  type tcom= creer_type(0,0,T_com);
     /* N110=creer_noe(V,tbot,resg,NULL,NULL):   resgN */
   /* N111=creer_noe(V,tbot,resd,NULL,NULL): resdN */
   N11=creer_noe(op,top,nomop(op),resgN,resdN);
   N10=creer_noe(V,top,dest,NULL,NULL);/* feuille */
   N1=creer_noe(Af,tcom,"Af",N10,N11);
      res=creer_noe(Se,tcom,"Se",crps,N1);/* de racine Se, meme si crps==NULL       */
     return(res);
}
/* traduit ppascal dans mini-Pascal: applatit les expressions                    */
/* modifie *e ; ajoute des variables dans rho                                    */
/* transforme l'expression en une feuille Var  ou  I ou true ou false ou         */
/* une commande Se(seqN(cg,cd),Af(Var,op(resg,resd))) avec cg,cd plates          */
/* Var inseree dans rho                                                          */
/* seqN(cg,cd)-> NULL ssi *e est de hauteur 1                                    */
extern void applat_exp(BILENVTY *rho, NOE *e)
{ assert(e != NULL);
  if(*e != NULL)
    { type te;             /* type de *e                       */
      type tbot= creer_type(0,0,T_bot);/* type par defaut      */
      type tcom= creer_type(0,0,T_com);
      type tint= creer_type(0,0,T_int);
      NOE fg, fd;         /* fils gauches , droits             */
      NOE cg,cd;         /* corps des applatissements des fils */
      NOE compg,compd;   /* com_plates  des fils               */
      char *resd;        /* adresse resultat fils droit        */
      NOE resgN, resdN;  /* noeuds des resultats des fils      */
      NOE newcorps;      /* corps du resultat                  */
      char *newvar;             /* nouvelle variable           */
      switch((*e)->codop)
	{case true:case false:
	   return; /* deja plate */
        case Ind:case Pl:case Mo:case Mu:case And:case Or:case Lt:case Eq:///* op bin */
	case Not:case NewAr:/* op unaire */
	  /* extraire les applatissements des fils */
	  {fg=(*e)->FG;fd=(*e)->FD;           /* fd ==NULL ou fd ==NULL si op unaire   */
	  applat_exp(rho,&fg);/* applatir fils gauche, extraire les ingredients        */
	  	  if (est_feuille(fg))
	    resgN=copier_noe(fg);
	  else
	    {resgN=creer_noe(V,tbot,adresse(fg),NULL,NULL);
	    };
	  cg=corps(fg);
	  compg=com_plate(fg);
	  	  applat_exp(rho,&fd);/* applatir fils droit, extraire les ingredients        */
	  	  if (est_feuille(fd))
	    resdN=copier_noe(fd);
	  else
	    {resdN=creer_noe(V,tbot,adresse(fd),NULL,NULL);
	    };
	  cd=corps(fd);
	  	  compd=com_plate(fd);
	  	  newvar=gensym("var#");                          /* generer une nouvelle var */
	  ajout_var(rho, newvar, tint);                  /* ajouter newvar dans rho   */
	  	  newcorps=seqN(seqN(cg,cd),seqN(compg,compd));
	  	  (*e)=comb_exp((*e)->codop,te,newcorps,resgN,resdN,newvar);/* applatir e    */
	  	  return;}
	case I:                                                 /* constante entiere */
	  	  return;/* deja plate */
	case V:                                         /* variable                   */
	  return;/* deja plate */
	case Ap:                                        /* appel fonction  unaire     */
	  {fd=(*e)->FD;            /* fd= suite des arguments, nomf = (*e)->FG->ETIQ  */
	   cg=NULL;                                 /* commande d'evaluation des args */
	   while (fd)                           
	     {assert(fd->codop==ArgAp);
	      cd=fd->FG;                            /* arg courant */
	      applat_exp(rho,&cd);
	      resd= adresse(cd);                   /* var qui recoit val(arg courant) */
	      /* ou chaine nomop(c->codop) si  cd ->codop \in \{true, false,I \}      */
	      if (cd->codop ==Se)  /* si cd == suite d'Affectations                   */
	        {/* arg de f devient variable */
		 fd->FG=creer_noe(V,tbot,resd,NULL,NULL);
		 cg=creer_noe(Se,tbot,"Se",cg,cd);/* monter la suite des evals        */
		}
	      /* sinon cd == feuille de type V                                        */
	      fd=fd->FD;                           /* descendre dans la liste d'args  */
	     };
	   /* cg= suite des eval des args; fd ==NULL */
	   newvar=gensym("var#");                        /* generer une nouvelle var  */
	   ajout_var(rho, newvar, tint);                 /* ajouter newvar dans rho   */
	   /* reconstruire  e */
	   NOE N10=creer_noe(V,te,newvar,NULL,NULL);                       /* feuille */
           NOE N1=creer_noe(Af,tcom,"Af",N10,*e);
           *e=creer_noe(Se,tcom,"Se",cg,N1);
	   return;
	  }
	default: return;  /* codop inconnu au bataillon */
	  }
	}
  else
    return;/* applatissement de NULL vaut NULL */
}

/* traduit ppascal dans mini-Pascal: applatit les commandes                      */
/* modifie c ; ajoute des variables dans rho                                     */
void applat_com(BILENVTY *rho, NOE *c)
{ NOE fg,fd,cg,cd; NOE cond;int opd;char *resd;
  type tcom= creer_type(0,0,T_com);
  type tboo= creer_type(0,0,T_boo);
  type tbot= creer_type(0,0,T_bot);
 if(*c != NULL)
   {  fg=(*c)->FG; fd=(*c)->FD;
      switch((*c)->codop)
       {case Mp:
	   applat_com(rho, &((*c)->FG));
	   return;/*                                                                  */
 	case Af:
	  if ((fg->codop ==V)&&(est_feuille(fd)))   /* affectation V:=V ou V:=I       */
	      return;/* deja plate */
	  else if (fg->codop==V)                   /* affectation V:=e, e non feuille */
	    {	     applat_exp(rho,&fd);
	     	     suppr_var(rho, fd->FD->FG->ETIQ, fd->FD->FG->typno); /* tuer la var aux */
	     free(fd->FD->FG);        
	     fd->FD->FG=fg;                                       /* var aux--> var V */
	     	     /*free(fg); A VOIR de pres */
	     free(*c);
	     *c=fd;}
	  else                                   /* affectation a un tableau: Et[Z]=e */
	    {applat_exp(rho,&fg);                /* extraire les morceaux             */
	     type td;                            /* type de e                         */
	     type_copy(&td,fd->typno);
	     if (est_feuille(fd))                /*op de fd:(V,I,true,false)si feuille*/
	       opd= fd->codop;
	     else
	       opd=V;
	     applat_exp(rho,&fd);
	     cg=corps(fg);
	     cd=corps(fd);                       /* cd==NULL si fd est de hauteur <=1 */
	     char *add=Idalloc();
	     if (!(est_feuille(fd)))             /* cas ou fd != feuille */
	       strcpy(add,adresse(fd));
	     NOE expplatg=exp_plate(fg);
	     	     NOE compd=com_plate(fd);
	     	     NOE N0,N1,N11;
	     N0=seqN(seqN(cg,cd),compd);           /* assembler les commandes      */
	     	     if (!(est_feuille(fd)))
	       N11=creer_noe(opd,td,add,NULL,NULL);
	     else
	       N11=fd;
	     	     N1=creer_noe(Af,tcom,"Af",expplatg,N11); /* la commande plate finale     */
	     *c=seqN(N0,N1);
	    }
	  return;	    
	case Sk: return; /* deja plate */
	case Se:
	     applat_com(rho, &((*c)->FG));
	    	     	    applat_com(rho, &((*c)->FD));
	    	     *c=seqN((*c)->FG,(*c)->FD);
	     /* NOE res=creer_noe(Se,tcom,"Se",(*c)->FG,(*c)->FD);*/
	     	  return; 
	case If:
	  cond=(*c)->FG;                                         /* expression cond   */
	  applat_com(rho,&((*c)->FD->FG));                       /* cas true          */
	  cg=(*c)->FD->FG;                                       
	  applat_com(rho,&((*c)->FD->FD));                       /* cas false         */ 
	  cd=(*c)->FD->FD;
	  if (!est_feuille(cond))                             /* cond neq     feuille */ 
	    {applat_exp(rho, &((*c)->FG));
	     cond=(*c)->FG;
	     char *adcond=adresse(cond);
	     NOE N10=creer_noe(V,tboo,adcond,NULL,NULL);
	     NOE N11=creer_noe(V,tbot,"",cg,cd);
	     NOE N1=creer_noe(If,tcom,"If",N10,N11);
	     *c=creer_noe(Se,tcom,"Se",cond,N1);
	    };
	  return;
	case Wh:
	  /* fg= expression d'entree, fd= corps                                       */
	  applat_com(rho,&((*c)->FD));
	  fd=(*c)->FD;
	  if (!est_feuille(fg))                             /* fg   neq     feuille   */
	    {applat_exp(rho,&((*c)->FG));
	     fg=(*c)->FG;
	     	     char *adcond=Idalloc();
	     strcpy(adcond,adresse(fg));
	     	     /* reconstruire  *c */
	     NOE N11=creer_noe(Se,tcom,"Se",fd,fg);                  /* nouveau corps */
	     	     NOE N10=creer_noe(V,tboo,adcond,NULL,NULL);             /* nouvelle cond */
             NOE N1=creer_noe(Wh,tcom,"Wh",N10,N11);/* nouveau wh apres nouvelle cond */
             *c=creer_noe(Se,tcom,"Se",fg,N1);                       /* le nouveau wh */
	    }
	  return;
        case Ap:/* analogue au meme cas dans applat_exp */
	   fd=(*c)->FD;                 /* fd= suite des arguments, nomf = c->FG->ETIQ*/
	   cg=NULL;                                 /* commande d'evaluation des args */
	   while (fd)                           
	     {assert(fd->codop==ArgAp);
	      cd=fd->FG;                            /* arg courant */
	      applat_exp(rho,&cd);
	      /* ou chaine nomop(c->codop) si  cd ->codop \in \{true, false,I \}      */
	      if (cd->codop==Se)
		{/*arg de f devient une variable */
		 resd= adresse(cd);                /* var qui recoit val(arg courant)*/
		 fd->FG=creer_noe(V,tcom,resd,NULL,NULL);
		 cg=seqN(cg,cd);                      /*  monter la suite des evals   */
		}
	      fd=fd->FD;                           /* descendre dans la liste d'args  */
	      	      /* sinon cd == feuille d'operateur V ou I ou true ou false              */
	     }
	   /* cg= suite des eval des args; fd ==NULL */
	   /* reconstruire c */
	   *c=seqN(cg,*c);
	  return;
	default: return;
	}
    };
return;
}

/* applatit les commandes dans le programme                                      */
void applat_prog(BILENVTY *rho, BILFON bfon, NOE *corps)
{applat_com(rho,corps);
  LFON pfon= bfon.debut; /* pointe sur la fonction courante */
 while (pfon)
   {applat_com(&(pfon->VARLOC),&(pfon->CORPS));
          pfon=pfon->SUIV;
   }
 return;
}

/* c est une exp applatie: Ind(X,Y)                            */
/* modifie c : 4 affectations qui traduisent Ind dans l'interp */
void chasse_ind(BILENVTY *rho, NOE *c)
{ if (*c == NULL)
    {return;}
  else
    {NOE adN,expN,ADRN,TASN;/* feuilles decrivant nom du tab,exp,ADR#,TAS# */
     NOE IND1,IND10;
     type tar1= creer_type(1,0,T_int);
     type tint= creer_type(0,0,T_int);
     adN=copier_noe((*c)->FG);       /* nom du tab resultat                        */
     expN=copier_noe((*c)->FD);     /* nom de la var/Ct qui definit l'index        */
     ADRN=creer_noe(V,tar1,"ADR#",NULL,NULL);/* ADR#: array of int                 */
     TASN=creer_noe(V,tar1,"TAS#",NULL,NULL);/* TAS#: array of int                 */
     IND10=creer_noe(Ind,tint,"Ind",ADRN,adN);
     IND1=creer_noe(Pl,tint,"Pl",IND10,expN);
     free((*c)->FG); free((*c)->FD);
     *c=creer_noe(Ind,tint,"Ind",TASN,IND1);
     return;
    }
}

/* c est une commande applatie; elle peut contenir des NewAr,des Ind             */
/* modifie c : chasse les tableaux dynamiques, les operations Ind  et NewAr      */
void chasse_tab(BILENVTY *rho, NOE *c)
{ if (*c == NULL)
    {return;}
  else if (((*c)->codop==Af)&& ((*c)->FD->codop==NewAr))
    /*    *c==Af(X,NewAr(NULL,exp)                                */
    {/*   5 affectations qui traduisent NewAr dans l'interpreteur */
      NOE AF1,AF2,AF21,AF3,AF30,AF4,AF40,AF5,AF51;
      NOE UN; /* noeud pour la constante 1 */
      /* feuilles decrivant nom du tab,exp,padrln#,ADR#,ptasl#,TAL# */
      NOE adN,expN,PADRLN,ADRN,PTASLN,TALN;
      type tcom= creer_type(0,0,T_com);
      type tint= creer_type(0,0,T_int);
      type tar1= creer_type(1,0,T_int);
      assert((*c)->FD->FG==NULL);
      adN=copier_noe((*c)->FG);          /* nom du tab resultat                     */
      expN=copier_noe((*c)->FD->FD);     /* nom de la var/Ct qui definit la taille  */
      PADRLN=creer_noe(V,tint,"padrl#",NULL,NULL);/* padrl#: int                    */
      ADRN=creer_noe(V,tar1,"ADR#",NULL,NULL);/* ADR#: array of int                 */
      PTASLN=creer_noe(V,tint,"ptasl#",NULL,NULL);/* ptasl#: int                    */
      TALN=creer_noe(V,tar1,"TAL#",NULL,NULL);/* TAL#: array of int                 */
      UN=creer_noe(I,tint,"1",NULL,NULL);/* constante 1                             */
      AF1=creer_noe(Af,tcom,"Af",adN,PADRLN);
      AF21=creer_noe(Pl,tint,"Pl",PADRLN,UN);
      AF2=creer_noe(Af,tcom,"Af",PADRLN,AF21);
      AF30=creer_noe(Ind,tint,"Ind",ADRN,adN);
      AF3=creer_noe(Af,tcom,"Af",AF30,PTASLN);
      AF40=creer_noe(Ind,tint,"Ind",TALN,adN);
      AF4=creer_noe(Af,tcom,"Af",AF40,expN);
      AF51=creer_noe(Pl,tint,"Pl",PTASLN,expN);
      AF5=creer_noe(Af,tcom,"Af",PTASLN,AF51);
      free((*c)->FG); free((*c)->FD->FD);free((*c)->FD);free(*c);
      *c=seqN(seqN(seqN(seqN(AF1,AF2),AF3),AF4),AF5);
    }
  else if (((*c)->codop==Af)&& ((*c)->FD->codop==Ind))
    /* 4 affectations qui traduisent Ind dans l'interp     */
    {chasse_ind(rho,&((*c)->FD));
     applat_com(rho, c);
     }
  else if (((*c)->codop==Af)&& ((*c)->FG->codop==Ind))
    /* 4 affectations qui traduisent Ind dans l'interp     */
    {chasse_ind(rho,&((*c)->FG));
     applat_com(rho, c);
    }
  else      /* traiter les fils */
    {chasse_tab(rho,&((*c)->FG));
     chasse_tab(rho,&((*c)->FD));
     return;
    }
}

/* applatit puis chasse les tableaux dynamiques             */
/* le corps du MP et les corps des foncs/pro sont plats     */
/* il ne reste que 3 tableau et 3 NewAr(a effacer dans C3A) */
/* ttas est la taille de TAS#, tadr la taille de ADR#       */
void chasse_tab_prog(BILENVTY *rho, BILFON bfon, NOE *corps, int ttas, int tadr)
{/* ajouter ADR#, TAL#, TAS#, padrl#, ptasl# dans rho       */
 type tcom= creer_type(0,0,T_com);
 type tar1= creer_type(1,0,T_int);
 type tint= creer_type(0,0,T_int);
 ajout_var(rho, "ADR#", tar1);
 ajout_var(rho, "TAL#", tar1);
 ajout_var(rho, "TAS#", tar1);
 ajout_var(rho, "padrl#", tint);
 ajout_var(rho, "ptasl#", tint);
 /* initialiser ces variables */
 BILENVTY rho_lc= bilenvty_vide() ;
 affectb(*rho, rho_lc,"padrl#", 1);/* 0 denote nil */
 affectb(*rho, rho_lc,"ptasl#", 1);/* zone du tas qui ne code pas nil */
 /* appliquer chasse_tab au prog principal */ 
  chasse_tab(rho,corps);
 /* ajouter (en tete) l'initialisation de ADR#,TAL#,TAS# */
  NOE ADR0,ADR1,ADR11,ADRN,TL0,TL1,TL11,TLN,TS0,TS1,TS11,TSN;
  ADR0=creer_noe(V,tar1,"ADR#",NULL,NULL);
  char tadrs[MAXIDENT];
  sprintf(tadrs,"%d",tadr);
  ADR11=creer_noe(I,tint,tadrs,NULL,NULL);
  ADR1=creer_noe(NewAr,tar1,"NewAr",NULL,ADR11);
  ADRN=creer_noe(Af,tcom,"Af",ADR0,ADR1);
  TL0=creer_noe(V,tar1,"TAL#",NULL,NULL);
    /* meme taille que ADR# */
  TL11=creer_noe(I,tint,tadrs,NULL,NULL);
  TL1=creer_noe(NewAr,tar1,"NewAr",NULL,TL11);
  TLN=creer_noe(Af,tcom,"Af",TL0,TL1);
  TS0=creer_noe(V,tar1,"TAS#",NULL,NULL);
  char ttass[MAXIDENT];
  sprintf(ttass,"%d",ttas);
  TS11=creer_noe(I,tint,ttass,NULL,NULL);
  TS1=creer_noe(NewAr,tar1,"NewAr",NULL,TS11);
  TSN=creer_noe(Af,tcom,"Af",TS0,TS1);
  *corps=seqN(seqN(seqN(ADRN,TLN),TSN),*corps);
 LFON pfon= bfon.debut; /* pointe sur la fonction courante */
 while (pfon)
   {chasse_tab(&(pfon->VARLOC),&(pfon->CORPS));/* corps de fonction/pro */
        pfon=pfon->SUIV;
   }
 return;}

/* c est une commande applatie, sans tableau; peut contenir des appels de fonc   */
/* modifie c : chasse les appels de fonc                                         */
void chasse_fonc_all(BILENVTY *rho, NOE *c)
{ if (*c == NULL)
    {return;}
  else if (((*c)->codop==Af)&& ((*c)->FD->codop==Ap))
    /*    *c==Af(lhs,Ap(fonc,largs); lhs est une var, fonc un nom de fonction      */
    { NOE lhs,rhs,fonc;
      NOE N11; /* nouveau noeud pour la var globale fonc#                          */
      NOE N1; /* nouveau noeud pour l'affectation du resultat du calcul de fonc    */
      NOE res;
      type tcom= creer_type(0,0,T_com);
      assert((*c)->FG->codop==V);
      lhs= (*c)->FG;
      rhs= (*c)->FD;
      fonc=(*c)->FD->FG;/* nom de la fonction */
      N11=copier_noe(fonc);
      strcat(N11->ETIQ,"#");   /* fonc +"#"*/
      N1=creer_noe(Af,tcom,"Af",lhs,N11);
      res=seqN(rhs,N1);
      free(*c);
      *c=res;
     }
  else /* traiter les fils */
    {chasse_fonc_all(rho,&((*c)->FG));
     chasse_fonc_all(rho,&((*c)->FD));
     return;
    }
}

/* *c  est applati, sans tab; modifie les affectations a nfonc                  */
/* nfonc -> nfonc# partout ou nfonc est un id de variable (pas le fg d'un Ap)   */
void chasse_fonc_dieze(char *nfonc,NOE *c)
{  if (*c == NULL)
    {return;}
  else if ((*c)->codop==Ap)
    /* le fils gauche ne doit pas etre renomme : ca peut etre nfonc */
    chasse_fonc_dieze(nfonc,&((*c)->FD));
  else if (((*c)->codop==V)&& (strcmp((*c)->ETIQ,nfonc)==0))
    /*  nfonc est un operande ou bien un lhs, pas un id de fonction */
      strcat((*c)->ETIQ,"#");/* remplacer nfon par la nouvelle var nfon#         */
  else /* traiter les fils */
    {chasse_fonc_dieze(nfonc,&((*c)->FG));
     chasse_fonc_dieze(nfonc,&((*c)->FD));
     return;
    }
}/* trop violent: renomme meme nfonc(args) en nfonc#(args) A CORRIGER:fait   */

/* *c  est applati, sans tab; modifie les affectations a nfonc                  */
/* Af(nfonc,rhs) -->  Af(nfonc#,rhs)   et initialisation de nfonc#              */
void chasse_fonc_self(char *nfonc,NOE *c)
{ chasse_fonc_dieze(nfonc,c);
  /* initialisation   */
  NOE N00,N01,N0;
  type tint= creer_type(0,0,T_int);
  type tcom= creer_type(0,0,T_com);
  char *nnfonc=Idalloc();
  /* N0= Af(nfonc#,0) */
  strcpy(nnfonc,nfonc);
  strcat(nnfonc,"#");
  N00=creer_noe(V,tint,nnfonc,NULL,NULL);
  N01=creer_noe(I,tint,"0",NULL,NULL);
  N0=creer_noe(Af,tcom,"Af",N00,N01);
  /* initialiser c, puis le corps dieze */
  *c=seqN(N0,*c);
}/* semble faux le 15/04/17 */

/* le corps de pfon est suppose applati, sans tab                                */
/* modifie le corps de pfon, ses varlocs  et declare une var globale             */
void chasse_fonc_loc(BILENVTY *rho, LFON  pfon)
{ NOE *c; char *nfon; type tp;
  type tcom= creer_type(0,0,T_com);
  c= &(pfon->CORPS);
  nfon=Idalloc();
  strcpy(nfon,pfon->ID); /* nom de la fonction  */
  tp= pfon->TP;
  /* traiter le corps */
  if (type_eq(tp,tcom))/*       procedure  */
    {chasse_fonc_all(rho,c);}
  else                 /*       fonction   */
    { chasse_fonc_all(rho,c);  /* supprime les appels de fonc                        */
      /* ajouter nfon# comme var globale */
      char *nnfonc=Idalloc();
      strcpy(nnfonc,nfon);
      strcat(nnfonc,"#");
      ajout_var(rho, nnfonc, tp);
      /* affectation finale   */
      NOE N00,N01,N0;
      type tcom= creer_type(0,0,T_com);
      /* N0= Af(nfonc#,nfonc) */
      N00=creer_noe(V,tp,nnfonc,NULL,NULL);
      N01=creer_noe(V,tp,nfon,NULL,NULL);
      N0=creer_noe(Af,tcom,"Af",N00,N01);
      /* terminer le corps de nfon par N0*/
      *c=seqN(*c,N0);
    };
}

/* le programme est applati, sans tab                                          */
/* chasse les fonctions  (chaque fonc devient une procedure)                   */
/* modifie les arguments                                                       */
void chasse_fonc_prog(BILENVTY *rho_gb, BILFON bfon, NOE *corps)
{/* traiter les fonctions */
 LFON pfon= bfon.debut; /* pointe sur la fonction courante */
 while (pfon)
   {chasse_fonc_loc(rho_gb,pfon);/* traite la fonction/pro */
    type tcom= creer_type(0,0,T_com);
    pfon->TP=tcom;                /* devient une procedure */
    pfon=pfon->SUIV;
   };
 /* traiter le corps      */
 chasse_fonc_all(rho_gb,corps);
 return;
}

/* *c est une constante bool; la traduit en numeral entier                     */
/* le programme devient non-typable , mais reste interpretable par semop_gp    */
void traduit_const(NOE  *c)
{ if ((*c)->codop==true)
    {(*c)->codop=I; (*c)->ETIQ="1";}
  else if ((*c)->codop==false)
    {(*c)->codop=I; (*c)->ETIQ="0";};
  return;
}
  
/* la commande *c est supposee applatie, sans tab , sans fonc                  */
/* chasse les constantes des exp de hauteur 1                                  */
/* les repousse dans des affectations Af(var,0) , Af(var,1), Af(var, Cte)      */
/* modifie les arguments                                                       */
void chasse_const(BILENVTY *rho, NOE  *c)
{ NOE argg,argd,cg,cd,vargN,vardN;
  char *varg; char *vard;
  type tint= creer_type(0,0,T_int);
  type tcom= creer_type(0,0,T_com);
    if (*c == NULL)
    {return;}
  else if (((*c)->codop==Af)&& ((*c)->FD->codop==NewAr))
    /* OK pour C3A et pour Y86: tab constant, dimension connue a la compilation */
    {return;
     }
  else if (((*c)->codop==Af)&& ((*c)->FG->codop==V)&& (est_feuille((*c)->FD)))
    /* Af(var,feuille):OK     */
    {return;
     }
  else if (((*c)->codop==Af)&& ((*c)->FG->codop==V)&& (!est_feuille((*c)->FD)))
    /* Af(var,op(argg,argd) */
    { argg= (*c)->FD->FG;argd= (*c)->FD->FD;
      if (est_var(argg) && est_var(argd))
	return;
      else /* un au moins de argg,argd est cst */
	{ if (est_const(argg))
	    {varg=gensym("var#");
	     ajout_var(rho, varg, tint); 
	     vargN=creer_noe(V,tint,varg,NULL,NULL);
	     /* traduit_const(&argg); */
	     cg=creer_noe(Af,tcom,"Af",vargN,copier_noe(argg));
	     	    }
	  else
	    {vargN=copier_noe(argg);
	     cg=NULL;
	    };
	  if (est_const(argd))
	    {vard=gensym("var#");
	     ajout_var(rho, vard, tint);
	     vardN=creer_noe(V,tint,vard,NULL,NULL);
	     /* traduit_const(&argd); */
	     cd=creer_noe(Af,tcom,"Af",vardN,copier_noe(argd));
	     	    }
	  else
	    {vardN=copier_noe(argd);
	     cd=NULL;
	    };
	  /* nouvelle commande */
	  NOE N11=creer_noe((*c)->FD->codop,tint,nomop((*c)->FD->codop),copier_noe(vargN),copier_noe(vardN));
	  NOE N10=copier_noe((*c)->FG);
	  NOE N1= creer_noe(Af,tcom,"Af",N10,N11);
	  	  *c=seqN(seqN(cg,cd),N1);
	  return;
	}
    }
  else if (((*c)->codop==Af)&& ((*c)->FG->codop==Ind))
    /* Af(Ind(tab,argg),argd) */
    {assert(est_feuille((*c)->FD)); /* c est plate */
     argg= (*c)->FG->FD;argd= (*c)->FD;
     if (est_var(argg) && est_var(argd))
       {       return;}
     else /* un au moins de argg,argd est cst */
       {	if (est_const(argg))
	   {varg=gensym("var#");
	    ajout_var(rho, varg, tint); 
	    vargN=creer_noe(V,tint,varg,NULL,NULL);
	    traduit_const(&argg); 
	    cg=creer_noe(Af,tcom,"Af",vargN,copier_noe(argg));
	    	    }
	 else
	   {vargN=copier_noe(argg);
	    cg=NULL;
	    };
	 if (est_const(argd))
	   {vard=gensym("var#");
	    ajout_var(rho, vard, tint);
	    vardN=creer_noe(V,tint,vard,NULL,NULL);
	    traduit_const(&argd); 
	    cd=creer_noe(Af,tcom,"Af",vardN,copier_noe(argd));
	    	   }
	  else
	   {vardN=copier_noe(argd);
	    cd=NULL;
	   };
	 /* nouvelle commande */
	 NOE N100=copier_noe((*c)->FG->FG);
	 NOE N10= creer_noe(Ind,tint,"Ind",N100,copier_noe(vargN));
	 NOE N1= creer_noe(Af,tcom,"Af",N10,copier_noe(vardN));
	 	  *c=seqN(seqN(cg,cd),N1);
	  return;
	}
    }
  else      /* traiter les fils */
    {chasse_const(rho,&((*c)->FG));
     chasse_const(rho,&((*c)->FD));
     return;
    }
}

/* le programme est applati, sans tab , sans fonc                              */
/* chasse les constantes des exp de hauteur 1                                  */
/* modifie les arguments                                                       */
void chasse_const_prog(BILENVTY *rho_gb, BILFON bfon, NOE *corps)
{/* traiter les fonctions */
 LFON pfon= bfon.debut; /* pointe sur la fonction courante */
 while (pfon)
   {chasse_const(&(pfon->VARLOC),&(pfon->CORPS));/* traiter la pro */
    pfon=pfon->SUIV;
   };
 /* traiter le corps */
  chasse_const(rho_gb,corps);
 return;
}




 

