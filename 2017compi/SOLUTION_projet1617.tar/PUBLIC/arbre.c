/* arbre.c */
#include <assert.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arbre.h"
#include "ppascal.tab.h"
#include "interp_mp.h"
/*-------------------------------------------------------------------*/
/* ----------------------------types---------------------------------*/
/*  type, NOE,ENVTY,LFON,BILENVTY,BILFON : definis dans arbre.h      */
/*-------------------------------------------------------------------*/
/*---------------------allocation memoire----------------------------*/
char *Idalloc()
{
  return((char *)malloc(MAXIDENT*sizeof(char)));
}
NOE Nalloc()
{
  return((NOE)malloc(sizeof(struct noeud)));
}
ENVTY Envtalloc()
{
  return((ENVTY)malloc(sizeof(struct cellenvty)));
}
type *talloc()
{
  return((type *)malloc(sizeof(type)));
}
LFON Lfonalloc()
{
  return((LFON)malloc(sizeof(struct cellfon)));
}
/*-------------------------------------------------------------------*/
/*--------------------------------arbres-----------------------------*/

void prefix(NOE n)
/* ecrit l'expression n en notation prefixe*/
{ if(n != NULL)
    { if (n->ETIQ)
	/* pour tests */
	printf("%s ",n->ETIQ);
      else
	printf("%s ",nomop(n->codop));
      prefix(n->FG);
      prefix(n->FD);
    };
}

/* 1 si est une feuille, 0 sinon */
int est_feuille(NOE n)
{if (n == NULL)
    return(0);
 else
   return ((n->FG==NULL)&&(n->FD==NULL));
}

/* 1 si est une variable, 0 sinon */
int est_var(NOE n)
{return ((est_feuille(n)) && (n->codop ==V));
}

/* 1 si est une constante, 0 sinon */
int est_const(NOE n)
{int res=est_feuille(n);
  res= res &&((n->codop ==I)|| (n->codop ==true) || (n->codop == false)); 
  return (res);
}

/* retourne NULL si ETIQ==NULL, un noeud avec ces champs, sinon */
/* ne modifie pas et n'incorpore pas les arguments              */
NOE creer_noe(int ncodop,type ntypno,char *NETIQ,NOE NFG,NOE NFD )
{ NOE res;
  if (NETIQ==NULL)
    res=NULL;
  else
    {res=Nalloc();
     res->codop=ncodop;
     res->typno=ntypno;
     res->ETIQ=Idalloc();
     strcpy(res->ETIQ,NETIQ);
     res->FG=NFG;
     res->FD=NFD;
     }
  return(res);
}

/* retourne une copie de n; ne modifie pas n; n'incorpore pas n                   */
/* incorpore les fils de n                                                        */
NOE copier_noe(NOE n)
{NOE res;
  if (n==NULL)
    return(NULL);
  else
    {res=creer_noe(n->codop,n->typno,n->ETIQ,n->FG,n->FD);
     return(res);
    };
}

/* retourne un noeud qui represente la commande cg Se cd */
/* incorpore les arguments */
NOE seqN(NOE cg,NOE cd)
{ NOE res;
  if (cg==NULL)
    res=cd;
  else if (cd == NULL)
    res=cg;
  else /* cg,cd non nuls */
    {res=Nalloc();
     res->codop=Se;
     res->typno=creer_type(0,0,T_com);
     res->ETIQ=Idalloc();
     strcpy(res->ETIQ,"Se");
     res->FG=cg;
     res->FD=cd;
     }
  return(res);
}
/* ecrit commande, Se -->   un saut de ligne    */
extern void ecrire_seqcom(NOE n)
{ if(n != NULL)
    {if (n->codop==Se)/* deux commandes */
       {if (!(n->FG))
	  ecrire_seqcom(n->FD);
	else if (!(n->FD))
	  ecrire_seqcom(n->FG);
	else
	  {ecrire_seqcom(n->FG);
	   printf("\n");
           ecrire_seqcom(n->FD);}
	}
      else if (n->codop==Wh)/* Wh e do c od */
	{printf("%s ",nomop(n->codop));
	ecrire_seqcom(n->FG);
	printf("do \n");
        ecrire_seqcom(n->FD);
	printf("\n");printf("od \n");
        }
      else if (n->codop==If)/* If e Th c El d */
	{printf("%s ",nomop(n->codop));
	ecrire_seqcom(n->FG);
	printf("\n");printf("then \n");
        ecrire_seqcom(n->FD->FG);
	printf("\n");printf("else \n");
	ecrire_seqcom(n->FD->FD);
	printf("\n");printf("fi \n");
        }
      else if (n->codop==Mp)/* Main Program*/
       {printf("%s ",n->ETIQ);
	printf("\n");
	ecrire_seqcom(n->FG);
        /* ecrire_seqcom(n->FD); en fait vide */
        }
      else if (n->ETIQ)/* commande atomique: une seule ligne */
	{printf("%s ", n->ETIQ);
	ecrire_seqcom(n->FG);
        ecrire_seqcom(n->FD);
        }
      else              /* commande atomique: une seule ligne */
       {printf("%s ",nomop(n->codop));
        ecrire_seqcom(n->FG);
        ecrire_seqcom(n->FD);
       }
     }
  else
    {return;
    }
}

/*-------------------------------------------------------------------*/
/*-----------------------------environnements------------------------*/
/* 1 si t1 ==t2 , 0 sinon                   */
int type_eq(type t1, type t2)
{return((t1.DIM==t2.DIM) && (t1.TYPEF==t2.TYPEF));
}

/* copie torig vers *tcop  */
void type_copy(type *tcop,type torig)
{tcop->DIM=torig.DIM;
 tcop->TAILLE=torig.TAILLE;
 tcop->TYPEF=torig.TYPEF;
 return;
}

/* affecte le type  de *prho      */
void type_affect(ENVTY rho,type tvar)
{(rho->TYPE).DIM=tvar.DIM;
 (rho->TYPE).TAILLE=tvar.TAILLE;
 (rho->TYPE).TYPEF=tvar.TYPEF;
 return;
}

/* retourne le type                  */
type creer_type(int dm, int tl, int tf)
{type TT;
  TT.DIM=dm;
  TT.TAILLE=tl;
  TT.TYPEF=tf;
  return(TT);
}

/* retourne le type resultat de op               */
extern type type_res_op(int op)
{ type t;
  switch(op)
    {case true:case false:case And:case Or:case Lt:case Eq:case Not:
	t=creer_type(0,0,T_boo);
	break;
     case Pl:case Mo:case Mu:
       t=creer_type(0,0,T_int);
       break;
      default:
	break;
    }
  return(t);
}
     
/* pointe vers cette var typee */
ENVTY creer_envty(char *etiq, type tau, int val)
{ENVTY ety;
  ety= Envtalloc();
  if (etiq !=NULL)
    {ety->ID=Idalloc();
      strcpy(ety->ID,etiq);}
  ety->TYPE=tau;
  ety->VAL=val;
  ety->SUIV=NULL;
  return(ety);
}

/* pointe vers copie  */
ENVTY copier_envty(ENVTY env)
{ENVTY ety = NULL;
  if (env != NULL)
  {
  ety= Envtalloc();
  if (env->ID!=NULL)
    {ety->ID=Idalloc();
     strcpy(ety->ID,env->ID);}
  type_copy(&(ety->TYPE),env->TYPE);
  ety->VAL=env->VAL;
  ety->SUIV= copier_envty(env->SUIV);
  }
return(ety);
}

/* retourne (arg1 op arg2) ou bien (op arg1) pour op "de base "*/
/* op <>  Ap ArgAp (appels de fonctions)                       */
int eval(int op, int arg1, int arg2)
{switch(op)
    {case Pl:
	return(arg1 + arg2);
    case Mo:
      return(arg1 - arg2);
    case Mu:
      return(arg1 * arg2);
    case Ind:
      return(TAS[arg1+arg2]);
    case And:
      return(arg1 * arg2);
    case Or:
      if (arg1 * arg2 == 0)
	return(arg1 + arg2);
      else
	return(1);
    case Not:
      return(1-arg1);/* l'argument est en position 1 */
    case Lt:
      if (arg1 < arg2)
	return(1);
      else
	return(0);
    case Eq:
      if (arg1 == arg2)
	return(1);
      else
	return(0);
    default:
      return(0);
    }
  return(0);
}
 
/* retourne l'adresse de la cellule contenant chaine. NULL si la chaine est absente */
ENVTY rechty(char *chaine, ENVTY listident)
{if (listident!=NULL)
    {if (strcmp(listident->ID,chaine)==0)
        { 	  return listident;}
      else
	return rechty(chaine,listident->SUIV);
    }
  else
    return NULL;
}

/* retourne la position de chaine dans les 2 environnements (rho_lc est prioritaire) */
/* retourne null ssi chaine est absente                                              */
ENVTY rechty2(char *chaine, ENVTY rho_gb, ENVTY rho_lc)
{ENVTY pos;
    pos=rechty(chaine,rho_lc);  
    if (pos==NULL)               /* chaine n'est pas dans rho_lc   */
      pos=rechty(chaine,rho_gb);
    return(pos);
}

/* affecte val a la variable var, dans rho */
/* NB: le type n'est pas utilise           */
int affectty(ENVTY rho, char *var, type tpvar, int val)
{ENVTY pos;
  pos=rechty(var,rho);/* adresse de la cellule contenant var */
    if (pos != NULL)
    {(pos->VAL)=val;
      (pos->TYPE)=tpvar;
      return(EXIT_SUCCESS);
    }
  else
    return(EXIT_FAILURE);
}

/* traduit entier (= codop) vers chaine (= nom operation)  */
/* utile pour les fonctions d'ecriture */
char *nomop(int codop)
{switch(codop)
    {case(I):return("I");
    case(V):return("V");
    case(Mp): return("Mp");
    case(Af): return("Af");
    case(Sk): return("Sk");
    case(NewAr): return("New_array_of");
    case(T_ar): return("array_of ");
    case(T_int): return("integer");
    case(T_boo): return("boolean");
    case(T_com): return("commande");
    case(T_bot): return("typ_indefini");
    case(T_err): return("typ_erreur");  
    case(true): return("true");
    case(false):return("false");
    case(Se): return("Se");
    case(Ind): return("Ind");  
    case(If): return("If");
    case(Th): return("Th");
    case(El): return("El");
    case(Wh): return("Wh");
    case(Do): return("Do");
    case(Ap): return("Ap");
    case(ArgAp): return("ArgAp");
    case(Pl): return("Pl");
    case(Mo): return("Mo");
    case(Mu): return("Mu");
    case(And):return("And");
    case(Or): return("Or");
    case(Not): return("Not");
    case(Lt): return("Lt");
    case(Eq): return("Eq");
    case(Afc): return("Afc");
    case(St): return("St");
    case(Jp): return("Jp");
    case(Jz): return("Jz");
    case(AfInd): return("AfInd");  /* Call Ret Param Paramc */
    case(Call): return("Call");
    case(Ret): return("Ret");
    case(Param): return("Param");
    case(Paramc): return("Paramc");  
    case(halt): return("halt");
    case(nop): return("nop");
    case(rrmovl): return("rrmovl");
    case(irmovl): return("irmovl");
    case(rmmovl): return("rmmovl");
    case(mrmovl): return("mrmovl");
    case(addl): return("addl");
    case(subl): return("subl");
    case(andl): return("andl");
    case(xorl): return("xorl");  
    case(jmp): return("jmp");
    case(je): return("je");
    case(call): return("call");
    case(ret): return("ret");
    case(pushl): return("pushl");
    case(popl): return("popl");
    case(0): return("");                   /* code 0: directive assembleur y86 */
    default: return(NULL);
    };
}

/* ecrit le type */
void ecrire_type(type tp)
{printf("DIM:%d,TAILLE:%d,TYPEF:%d",tp.DIM,tp.TAILLE,tp.TYPEF);
}

/* affiche l'environnement type      */  
int ecrire_envty(ENVTY rho)
{ if (rho==NULL)
    {printf("fin d'environnement \n");
      return(EXIT_SUCCESS);}
  else
    {printf("variable %s ",rho->ID);
      ecrire_type(rho->TYPE);
      printf("valeur %d \n",rho->VAL);
      ecrire_envty(rho->SUIV); 
      return(EXIT_SUCCESS);
    };
}

/* valeur de var dans rho  (UTILISEE ??)                     */
/* NB: la valeur d'un tableau est un index du tas            */
int valchty(ENVTY rho, char *var)
{ENVTY pos;
  pos=rechty(var,rho);/* adresse de la cellule contenant var */
  if (pos != NULL)
    return(pos->VAL);
  else
    return(0);
}

/* initialise var dans *prho */
/* le couple  (var,tvar)  est copie dans l'environnement */
void inbilenvty(BILENVTY *prho,char *var,type tvar)
{ENVTY erho, pos, newcell;
  erho=prho->debut;
      pos=rechty(var,erho);/* adresse de la cellule contenant var */
  if (pos == NULL)
    /*on insere var en tete de envrnt*/
    { 
      newcell=Envtalloc();
      newcell->ID=Idalloc();
      strcpy(newcell->ID,var);
      /* newcell->VAL=intalloc(); */
      newcell->VAL=0;
      type_affect(newcell,tvar);
      newcell->SUIV=erho;
            prho->debut=newcell;
    }
  else
    {
      /*TODO: tester coherence du type */
    }
}

/* retourne une biliste vide  */
BILENVTY bilenvty_vide()
{BILENVTY bty;
  bty.debut=NULL;bty.fin=NULL;
  return(bty);
}

/* retourne une biliste a un element */
BILENVTY creer_bilenvty(ENVTY varty)
{BILENVTY bty;
  bty.debut=varty;bty.fin=varty;
  return(bty);
}

/* pointe vers copie      */
BILENVTY copier_bilenvty(BILENVTY bty)
{ENVTY aty,ctycour; BILENVTY bcty;
  aty=copier_envty(bty.debut);
  bcty.debut=aty;
  ctycour=aty;
  while(ctycour && ctycour->SUIV)
      ctycour=ctycour->SUIV;
  bcty.fin=ctycour;
  return(bcty);
}

/* retourne la concatenation                       */
/* copie les deux arguments: pas de factorisation  */
BILENVTY concatty(BILENVTY bty1, BILENVTY bty2)
{BILENVTY bty,nbty1,nbty2;
  nbty1=copier_bilenvty(bty1);
  nbty2=copier_bilenvty(bty2);
  if (nbty1.fin!= NULL)
    if (nbty2.debut!=NULL)
       { nbty1.fin->SUIV=nbty2.debut;
        bty.debut=nbty1.debut;
        bty.fin=nbty2.fin;
        return(bty);}
    else
      return(nbty1);  
  else
    return(nbty2);
}

/* affiche la biliste de variables typees */
void ecrire_bilenvty(BILENVTY bty)
{ecrire_envty(bty.debut);
}

/* affecte  la valeur rhs a la variable lhs (rho_lc prioritaire) */
void affectb(BILENVTY rho_gb, BILENVTY rho_lc, char *lhs, int rhs)
{ENVTY pos;
    pos=rechty2(lhs,rho_gb.debut, rho_lc.debut);  
    if (pos!=NULL)
	pos->VAL=rhs;                   /* lhs est une var enregistree           */
    else
      printf("erreur: variable %s non declaree", lhs);
}

/* ajoute la variable typee (nomvar,tp) dans rho,en prem position, rho est modifie*/
void ajout_var(BILENVTY *rho, char *nomvar, type tp)
{ ENVTY vty=creer_envty(nomvar, tp,0);
  BILENVTY bvty=creer_bilenvty(vty);
  *rho= concatty(bvty,*rho);
  return;}

/* retourne l'adresse de la cellule precedent celle qui contient chaine */
/* NULL si cette cellule n'existe pas (par ex si chaine est en tete) */
ENVTY rechty_avant(char *chaine, ENVTY listident)
{if (listident && (listident->SUIV))
    {if (strcmp(listident->SUIV->ID,chaine)==0)
        return listident;
      else
	return rechty_avant(chaine,listident->SUIV);
    }
  else
    return NULL;
}

/* supprime la variable typee (nomvar,tp) dans rho */
void suppr_var_aux(ENVTY *rho, char *nomvar, type tp)
{   if (*rho)
    {if (strcmp((*rho)->ID,nomvar)==0)/* suppression en tete */
	{ENVTY newrho= (*rho)->SUIV;
	  free((*rho)->ID);free(*rho);
	 *rho=newrho;
	 	}
      else
	{ENVTY avant= rechty_avant(nomvar, *rho);
	    	  if (avant)
	    {ENVTY inutile= avant->SUIV;
	      avant->SUIV = avant->SUIV->SUIV;
	      free(inutile->ID);free(inutile);
	      	    }
	};
  return;
    }
}

/* supprime la variable typee (nomvar,tp) dans rho */
void suppr_var(BILENVTY *rho, char *nomvar, type tp)
{suppr_var_aux(&(rho->debut), nomvar, tp);
}
/*------------------------------ ------------------------------------------------*/
/*---------------------fonctions ------------------------------------------------*/
/* pointe vers cette fonction */
LFON creer_fon(char *nfon, BILENVTY lparam,BILENVTY lvars,NOE com,type tp)
{LFON lfn;
  lfn= Lfonalloc();
  if (nfon !=NULL)
    {lfn->ID=Idalloc();
      strcpy(lfn->ID,nfon);}
  lfn->PARAM=lparam;
  lfn->VARLOC=lvars;
  lfn->CORPS=com;
  lfn->TP=tp;
  return(lfn);
}

/* pointe vers une copie (sauf le corps qui est en facteur) */
LFON copier_fon(LFON lfn)
{LFON nlfn = NULL;
  if (lfn != NULL)
  {
  nlfn= Lfonalloc();
  if (lfn->ID!=NULL)
    {nlfn->ID=Idalloc();
     strcpy(nlfn->ID,lfn->ID);}
  nlfn->PARAM=copier_bilenvty(lfn->PARAM);
  nlfn->VARLOC=copier_bilenvty(lfn->VARLOC);
  nlfn->CORPS= lfn->CORPS; /* partie non-copiee */
  type_copy(&(nlfn->TP),lfn->TP);
    }
return(nlfn);
}

void ecrire_fon(LFON lfn)
{if (lfn==NULL)
    {printf("fin de liste de fonctions \n");
    }
  else
    {
    printf("nfon:%s",lfn->ID);
    printf("\n parametres:\n");
    ecrire_bilenvty(lfn->PARAM);
    printf("var locales:\n");
    ecrire_bilenvty(lfn->VARLOC);
    printf("corps (notation prefixe) :\n");
    prefix(lfn->CORPS);
    printf("\n type resultat:\n");
    ecrire_type(lfn->TP);
    printf("\n\n");
    ecrire_fon(lfn->SUIV);}
}
/* Se --> change de ligne */
void ecrire_fon_seqcom(LFON lfn)
{if (lfn==NULL)
    {printf("fin de liste de fonctions \n");
    }
  else
    {
    printf("nfon:%s",lfn->ID);
    printf("\n parametres:\n");
    ecrire_bilenvty(lfn->PARAM);
    printf("var locales:\n");
    ecrire_bilenvty(lfn->VARLOC);
    printf("corps (notation prefixe) :\n");
    ecrire_seqcom(lfn->CORPS);
    printf("\n type resultat:\n");
    ecrire_type(lfn->TP);
    printf("\n\n");
    ecrire_fon_seqcom(lfn->SUIV);}
}

/* retourne la position de chaine*/
LFON rechfon(char *chaine, LFON listident)
{if (listident!=NULL)
    {if (strcmp(listident->ID,chaine)==0)
        {	  return listident;}
      else
	return rechfon(chaine,listident->SUIV);
    }
  else
    return NULL;
}
/*------------------------------------------ ------------------------------------*/
/*---------------------bilistes-de-fonctions ------------------------------------*/
/* retourne une biliste vide  */
BILFON bilfon_vide()
{BILFON bfn;
  bfn.debut=NULL;bfn.fin=NULL;
  return(bfn);
}
  
/* retourne une biliste a un element */
BILFON creer_bilfon(LFON lfn)
{BILFON bfn;
  bfn.debut=lfn;bfn.fin=lfn;
  return(bfn);
}

BILFON copier_bilfon(BILFON bfn)     /* pointe vers une copie             */
{LFON afn,fncour; BILFON cfn;
  afn=copier_fon(bfn.debut);
  cfn.debut=afn;
  fncour=afn;
  while(fncour && fncour->SUIV)
      fncour=fncour->SUIV;
  cfn.fin=fncour;
  return(cfn);
}

/* retourne la concatenation*/
BILFON concatfn(BILFON bfn1, BILFON bfn2)
/* retourne la concatenation; ne detruit pas btyi; ne copie pas *btyi */
/* peut creer une boucle ! */
{BILFON bfn;
  if (bfn1.fin!= NULL)
    if (bfn2.debut!=NULL)
       { bfn1.fin->SUIV=bfn2.debut;
        bfn.debut=bfn1.debut;
        bfn.fin=bfn2.fin;
        return(bfn);}
    else
      return(bfn1);  
  else
    return(bfn2);
}

/* renvoie copie de la biliste                     */
/* de toutes les variables (params ou loc) de bfon */
BILENVTY allvars(BILFON bfon)
{BILENVTY bvarp,bvarl,res;
  bvarp = bfon.debut->PARAM;
  bvarl = bfon.debut->VARLOC;
  res= concatty(bvarp,bvarl);
  return(res);}
  
/* affiche la biliste de fonctions  */
void ecrire_bilfon(BILFON bfn)       
{ecrire_fon(bfn.debut);
}

/* affiche la biliste de fonctions, Se -->change de ligne  */
void ecrire_bilfon_seqcom(BILFON bfn)       
{ecrire_fon_seqcom(bfn.debut);
}

/*-------------------------------------------------------------------------------*/
/*---------------------programmes -----------------------------------------------*/
void ecrire_prog(BILENVTY argby,BILFON argbf,NOE argno)
{printf("Les variables globales:\n");
 printf("------------------------:\n");
 ecrire_bilenvty(argby);printf("\n");
 printf("Les fonctions:\n");
 printf("------------------------:\n");
 ecrire_bilfon(argbf);printf("\n");
 printf("Le programme principal:\n");
 printf("------------------------:\n");
 prefix(argno);printf("\n");
 return;
}
void ecrire_prog_seqcom(BILENVTY argby,BILFON argbf,NOE argno)
{printf("Les variables globales:\n");
 printf("------------------------:\n");
 ecrire_bilenvty(argby);printf("\n");
 printf("Les fonctions:\n");
 printf("------------------------:\n");
 ecrire_bilfon_seqcom(argbf);printf("\n");
 printf("Le programme principal:\n");
 printf("------------------------:\n");
 ecrire_seqcom(argno);printf("\n");
 return;
}
