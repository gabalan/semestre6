package abstractTree;

public interface EnvironmentInt {
	
	void putVariable(String var, Double value);
	Double getVariableValue(String variable);
	

}
